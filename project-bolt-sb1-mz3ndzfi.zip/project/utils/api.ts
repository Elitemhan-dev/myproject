// API utility functions for making HTTP requests

const API_BASE_URL = process.env.EXPO_PUBLIC_API_URL || '';

interface ApiResponse<T = any> {
  success: boolean;
  data?: T;
  error?: string;
}

class ApiError extends Error {
  constructor(public status: number, message: string) {
    super(message);
    this.name = 'ApiError';
  }
}

async function makeRequest<T = any>(
  endpoint: string,
  options: RequestInit = {}
): Promise<ApiResponse<T>> {
  try {
    const url = endpoint.startsWith('http') ? endpoint : `${API_BASE_URL}${endpoint}`;
    
    const response = await fetch(url, {
      headers: {
        'Content-Type': 'application/json',
        ...options.headers,
      },
      ...options,
    });

    const data = await response.json();

    if (!response.ok) {
      throw new ApiError(response.status, data.error || 'Request failed');
    }

    return { success: true, data };
  } catch (error) {
    console.error('API request failed:', error);
    
    if (error instanceof ApiError) {
      return { success: false, error: error.message };
    }
    
    return { success: false, error: 'Network error occurred' };
  }
}

// Authentication API
export const authApi = {
  async login(email: string, password: string) {
    return makeRequest('/api/auth/login', {
      method: 'POST',
      body: JSON.stringify({ email, password }),
    });
  },

  async signup(name: string, email: string, password: string) {
    return makeRequest('/api/auth/signup', {
      method: 'POST',
      body: JSON.stringify({ name, email, password }),
    });
  },

  async getProfile(token: string) {
    return makeRequest('/api/users/profile', {
      headers: { Authorization: `Bearer ${token}` },
    });
  },

  async updateProfile(token: string, profileData: any) {
    return makeRequest('/api/users/profile', {
      method: 'PUT',
      headers: { Authorization: `Bearer ${token}` },
      body: JSON.stringify(profileData),
    });
  },
};

// Products API
export const productsApi = {
  async getProducts(params?: { category?: string; search?: string; limit?: number; offset?: number }) {
    const searchParams = new URLSearchParams();
    if (params?.category) searchParams.append('category', params.category);
    if (params?.search) searchParams.append('search', params.search);
    if (params?.limit) searchParams.append('limit', params.limit.toString());
    if (params?.offset) searchParams.append('offset', params.offset.toString());
    
    const query = searchParams.toString();
    return makeRequest(`/api/products${query ? `?${query}` : ''}`);
  },

  async getProduct(id: string) {
    return makeRequest(`/api/products/${id}`);
  },

  async createProduct(token: string, productData: any) {
    return makeRequest('/api/products', {
      method: 'POST',
      headers: { Authorization: `Bearer ${token}` },
      body: JSON.stringify(productData),
    });
  },

  async updateProduct(token: string, id: string, productData: any) {
    return makeRequest(`/api/products/${id}`, {
      method: 'PUT',
      headers: { Authorization: `Bearer ${token}` },
      body: JSON.stringify(productData),
    });
  },

  async deleteProduct(token: string, id: string) {
    return makeRequest(`/api/products/${id}`, {
      method: 'DELETE',
      headers: { Authorization: `Bearer ${token}` },
    });
  },
};

// Orders API
export const ordersApi = {
  async getOrders(token: string, status?: string) {
    const query = status ? `?status=${status}` : '';
    return makeRequest(`/api/orders${query}`, {
      headers: { Authorization: `Bearer ${token}` },
    });
  },

  async getOrder(token: string, id: string) {
    return makeRequest(`/api/orders/${id}`, {
      headers: { Authorization: `Bearer ${token}` },
    });
  },

  async createOrder(token: string, orderData: any) {
    return makeRequest('/api/orders', {
      method: 'POST',
      headers: { Authorization: `Bearer ${token}` },
      body: JSON.stringify(orderData),
    });
  },

  async updateOrder(token: string, id: string, orderData: any) {
    return makeRequest(`/api/orders/${id}`, {
      method: 'PUT',
      headers: { Authorization: `Bearer ${token}` },
      body: JSON.stringify(orderData),
    });
  },
};

// Reviews API
export const reviewsApi = {
  async getProductReviews(productId: string) {
    return makeRequest(`/api/reviews?productId=${productId}`);
  },

  async createReview(token: string, reviewData: any) {
    return makeRequest('/api/reviews', {
      method: 'POST',
      headers: { Authorization: `Bearer ${token}` },
      body: JSON.stringify(reviewData),
    });
  },
};

// Analytics API
export const analyticsApi = {
  async getAnalytics(token: string) {
    return makeRequest('/api/analytics', {
      headers: { Authorization: `Bearer ${token}` },
    });
  },
};

// Email validation utility
export function isValidEmail(email: string): boolean {
  const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
  return emailRegex.test(email);
}

// Password validation utility
export function isValidPassword(password: string): boolean {
  return password.length >= 6;
}

// Token storage utilities
export const tokenStorage = {
  getToken(): string | null {
    if (typeof window !== 'undefined') {
      return localStorage.getItem('authToken');
    }
    return null;
  },

  setToken(token: string): void {
    if (typeof window !== 'undefined') {
      localStorage.setItem('authToken', token);
    }
  },

  removeToken(): void {
    if (typeof window !== 'undefined') {
      localStorage.removeItem('authToken');
    }
  },

  isTokenExpired(token: string): boolean {
    try {
      const decoded = JSON.parse(atob(token));
      return decoded.exp < Date.now();
    } catch {
      return true;
    }
  },
};