import React, { useState } from 'react';
import { View, Text, FlatList, StyleSheet, TouchableOpacity, Image } from 'react-native';
import { useRouter } from 'expo-router';
import { useOrders } from '@/context/OrderContext';
import { useAuth } from '@/context/AuthContext';
import { useTheme } from '@/context/ThemeContext';
import EmptyState from '@/components/EmptyState';
import { Package, ChevronRight, Clock, Truck, CircleCheck as CheckCircle, Circle as XCircle } from 'lucide-react-native';

export default function OrdersScreen() {
  const { getUserOrders } = useOrders();
  const { user } = useAuth();
  const { colors } = useTheme();
  const router = useRouter();
  const [selectedFilter, setSelectedFilter] = useState<'all' | 'pending' | 'processing' | 'shipped' | 'delivered'>('all');

  const orders = user ? getUserOrders(user.id) : [];
  const filteredOrders = selectedFilter === 'all' 
    ? orders 
    : orders.filter(order => order.status === selectedFilter);

  const getStatusIcon = (status: string) => {
    switch (status) {
      case 'pending':
        return <Clock size={16} color="#F59E0B" />;
      case 'processing':
        return <Package size={16} color="#3B82F6" />;
      case 'shipped':
        return <Truck size={16} color="#10B981" />;
      case 'delivered':
        return <CheckCircle size={16} color="#22C55E" />;
      case 'cancelled':
        return <XCircle size={16} color="#EF4444" />;
      default:
        return <Clock size={16} color="#6B7280" />;
    }
  };

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'pending': return '#F59E0B';
      case 'processing': return '#3B82F6';
      case 'shipped': return '#10B981';
      case 'delivered': return '#22C55E';
      case 'cancelled': return '#EF4444';
      default: return '#6B7280';
    }
  };

  const filterOptions = [
    { key: 'all', label: 'All' },
    { key: 'pending', label: 'Pending' },
    { key: 'processing', label: 'Processing' },
    { key: 'shipped', label: 'Shipped' },
    { key: 'delivered', label: 'Delivered' },
  ];

  const renderOrderItem = ({ item }: { item: any }) => (
    <TouchableOpacity 
      style={[styles.orderItem, { backgroundColor: colors.card, borderColor: colors.border }]}
      onPress={() => router.push(`/order/${item.id}`)}
    >
      <View style={styles.orderHeader}>
        <View>
          <Text style={[styles.orderId, { color: colors.text }]}>Order #{item.id}</Text>
          <Text style={[styles.orderDate, { color: colors.textSecondary }]}>
            {new Date(item.createdAt).toLocaleDateString()}
          </Text>
        </View>
        <View style={styles.orderStatus}>
          <View style={[styles.statusBadge, { backgroundColor: getStatusColor(item.status) + '20' }]}>
            {getStatusIcon(item.status)}
            <Text style={[styles.statusText, { color: getStatusColor(item.status) }]}>
              {item.status.charAt(0).toUpperCase() + item.status.slice(1)}
            </Text>
          </View>
          <ChevronRight size={20} color={colors.textSecondary} />
        </View>
      </View>

      <View style={styles.orderItems}>
        {item.items.slice(0, 3).map((orderItem: any, index: number) => (
          <Image
            key={index}
            source={{ uri: orderItem.product.image }}
            style={styles.itemImage}
          />
        ))}
        {item.items.length > 3 && (
          <View style={[styles.moreItems, { backgroundColor: colors.surface }]}>
            <Text style={[styles.moreItemsText, { color: colors.textSecondary }]}>
              +{item.items.length - 3}
            </Text>
          </View>
        )}
      </View>

      <View style={styles.orderFooter}>
        <Text style={[styles.itemCount, { color: colors.textSecondary }]}>
          {item.items.length} items
        </Text>
        <Text style={[styles.orderTotal, { color: colors.primary }]}>
          ${item.total.toFixed(2)}
        </Text>
      </View>
    </TouchableOpacity>
  );

  const styles = createStyles(colors);

  if (orders.length === 0) {
    return (
      <View style={[styles.container, { backgroundColor: colors.background }]}>
        <View style={[styles.header, { backgroundColor: colors.card, borderBottomColor: colors.border }]}>
          <Text style={[styles.title, { color: colors.text }]}>My Orders</Text>
        </View>
        <EmptyState
          icon={Package}
          title="No orders yet"
          subtitle="Your order history will appear here"
          buttonText="Start Shopping"
          onButtonPress={() => router.push('/(tabs)')}
        />
      </View>
    );
  }

  return (
    <View style={[styles.container, { backgroundColor: colors.background }]}>
      <View style={[styles.header, { backgroundColor: colors.card, borderBottomColor: colors.border }]}>
        <Text style={[styles.title, { color: colors.text }]}>My Orders</Text>
        <Text style={[styles.orderCount, { color: colors.textSecondary }]}>
          {orders.length} orders
        </Text>
      </View>

      <View style={[styles.filterContainer, { backgroundColor: colors.card }]}>
        <FlatList
          horizontal
          data={filterOptions}
          renderItem={({ item }) => (
            <TouchableOpacity
              style={[
                styles.filterChip,
                { backgroundColor: colors.surface, borderColor: colors.border },
                selectedFilter === item.key && { backgroundColor: colors.primary }
              ]}
              onPress={() => setSelectedFilter(item.key as any)}
            >
              <Text style={[
                styles.filterText,
                { color: colors.textSecondary },
                selectedFilter === item.key && { color: '#FFFFFF' }
              ]}>
                {item.label}
              </Text>
            </TouchableOpacity>
          )}
          keyExtractor={(item) => item.key}
          showsHorizontalScrollIndicator={false}
          contentContainerStyle={styles.filterList}
        />
      </View>

      <FlatList
        data={filteredOrders}
        renderItem={renderOrderItem}
        keyExtractor={(item) => item.id}
        contentContainerStyle={styles.ordersList}
        showsVerticalScrollIndicator={false}
      />
    </View>
  );
}

const createStyles = (colors: any) => StyleSheet.create({
  container: {
    flex: 1,
  },
  header: {
    paddingTop: 60,
    paddingBottom: 20,
    paddingHorizontal: 20,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.1,
    shadowRadius: 4,
    elevation: 3,
    borderBottomWidth: 1,
  },
  title: {
    fontSize: 24,
    fontWeight: '700',
    marginBottom: 4,
  },
  orderCount: {
    fontSize: 14,
  },
  filterContainer: {
    paddingVertical: 16,
  },
  filterList: {
    paddingHorizontal: 16,
  },
  filterChip: {
    paddingHorizontal: 16,
    paddingVertical: 8,
    borderRadius: 20,
    marginRight: 12,
    borderWidth: 1,
  },
  filterText: {
    fontSize: 14,
    fontWeight: '500',
  },
  ordersList: {
    padding: 16,
  },
  orderItem: {
    borderRadius: 12,
    padding: 16,
    marginBottom: 12,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.1,
    shadowRadius: 4,
    elevation: 2,
    borderWidth: 1,
  },
  orderHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: 12,
  },
  orderId: {
    fontSize: 16,
    fontWeight: '600',
    marginBottom: 2,
  },
  orderDate: {
    fontSize: 12,
  },
  orderStatus: {
    flexDirection: 'row',
    alignItems: 'center',
  },
  statusBadge: {
    flexDirection: 'row',
    alignItems: 'center',
    paddingHorizontal: 8,
    paddingVertical: 4,
    borderRadius: 12,
    marginRight: 8,
  },
  statusText: {
    fontSize: 12,
    fontWeight: '600',
    marginLeft: 4,
  },
  orderItems: {
    flexDirection: 'row',
    marginBottom: 12,
  },
  itemImage: {
    width: 40,
    height: 40,
    borderRadius: 8,
    marginRight: 8,
  },
  moreItems: {
    width: 40,
    height: 40,
    borderRadius: 8,
    justifyContent: 'center',
    alignItems: 'center',
  },
  moreItemsText: {
    fontSize: 12,
    fontWeight: '600',
  },
  orderFooter: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
  },
  itemCount: {
    fontSize: 14,
  },
  orderTotal: {
    fontSize: 16,
    fontWeight: '700',
  },
});