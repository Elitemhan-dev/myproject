import React, { useState } from 'react';
import { View, Text, StyleSheet, TouchableOpacity, FlatList, Alert } from 'react-native';
import { useAuth } from '@/context/AuthContext';
import { Package, Plus, Users, ChartBar as BarChart3, Settings } from 'lucide-react-native';

export default function AdminScreen() {
  const { user } = useAuth();
  const [activeTab, setActiveTab] = useState('overview');

  if (user?.role !== 'admin') {
    return (
      <View style={styles.container}>
        <Text style={styles.errorText}>Access Denied</Text>
      </View>
    );
  }

  const stats = [
    { label: 'Total Products', value: '156', color: '#2563EB' },
    { label: 'Total Orders', value: '89', color: '#10B981' },
    { label: 'Total Users', value: '234', color: '#F59E0B' },
    { label: 'Revenue', value: '$12,450', color: '#EF4444' },
  ];

  const recentOrders = [
    { id: '1', customer: 'John Doe', amount: '$299', status: 'pending' },
    { id: '2', customer: 'Jane Smith', amount: '$149', status: 'processing' },
    { id: '3', customer: 'Bob Johnson', amount: '$89', status: 'shipped' },
    { id: '4', customer: 'Alice Brown', amount: '$199', status: 'delivered' },
  ];

  const handleAddProduct = () => {
    Alert.alert('Add Product', 'Product management feature coming soon!');
  };

  const handleUpdateOrderStatus = (orderId: string, newStatus: string) => {
    Alert.alert('Update Order', `Order ${orderId} status updated to ${newStatus}`);
  };

  const renderOrderItem = ({ item }: { item: typeof recentOrders[0] }) => (
    <View style={styles.orderItem}>
      <View style={styles.orderInfo}>
        <Text style={styles.customerName}>{item.customer}</Text>
        <Text style={styles.orderAmount}>{item.amount}</Text>
      </View>
      <View style={styles.orderActions}>
        <View style={[styles.statusBadge, { backgroundColor: getStatusColor(item.status) }]}>
          <Text style={styles.statusText}>{item.status}</Text>
        </View>
        <TouchableOpacity
          style={styles.updateButton}
          onPress={() => handleUpdateOrderStatus(item.id, 'shipped')}
        >
          <Text style={styles.updateButtonText}>Update</Text>
        </TouchableOpacity>
      </View>
    </View>
  );

  return (
    <View style={styles.container}>
      <View style={styles.header}>
        <Text style={styles.title}>Admin Dashboard</Text>
        <Text style={styles.subtitle}>Welcome back, {user?.name}</Text>
      </View>

      <View style={styles.statsContainer}>
        {stats.map((stat, index) => (
          <View key={index} style={styles.statCard}>
            <Text style={styles.statValue}>{stat.value}</Text>
            <Text style={styles.statLabel}>{stat.label}</Text>
          </View>
        ))}
      </View>

      <View style={styles.quickActions}>
        <TouchableOpacity style={styles.actionButton} onPress={handleAddProduct}>
          <Plus size={20} color="#FFFFFF" />
          <Text style={styles.actionButtonText}>Add Product</Text>
        </TouchableOpacity>
        <TouchableOpacity style={styles.actionButton}>
          <Users size={20} color="#FFFFFF" />
          <Text style={styles.actionButtonText}>Manage Users</Text>
        </TouchableOpacity>
      </View>

      <View style={styles.ordersSection}>
        <Text style={styles.sectionTitle}>Recent Orders</Text>
        <FlatList
          data={recentOrders}
          renderItem={renderOrderItem}
          keyExtractor={(item) => item.id}
          style={styles.ordersList}
        />
      </View>
    </View>
  );
}

const getStatusColor = (status: string) => {
  switch (status) {
    case 'pending': return '#F59E0B';
    case 'processing': return '#2563EB';
    case 'shipped': return '#10B981';
    case 'delivered': return '#22C55E';
    default: return '#6B7280';
  }
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#F9FAFB',
  },
  header: {
    paddingTop: 60,
    paddingBottom: 20,
    paddingHorizontal: 20,
    backgroundColor: '#FFFFFF',
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.1,
    shadowRadius: 4,
    elevation: 3,
  },
  title: {
    fontSize: 24,
    fontWeight: '700',
    color: '#1F2937',
    marginBottom: 4,
  },
  subtitle: {
    fontSize: 16,
    color: '#6B7280',
  },
  statsContainer: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    padding: 16,
    gap: 12,
  },
  statCard: {
    flex: 1,
    minWidth: '45%',
    backgroundColor: '#FFFFFF',
    padding: 16,
    borderRadius: 12,
    alignItems: 'center',
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.1,
    shadowRadius: 4,
    elevation: 2,
  },
  statValue: {
    fontSize: 24,
    fontWeight: '700',
    color: '#1F2937',
    marginBottom: 4,
  },
  statLabel: {
    fontSize: 14,
    color: '#6B7280',
  },
  quickActions: {
    flexDirection: 'row',
    paddingHorizontal: 16,
    marginBottom: 16,
    gap: 12,
  },
  actionButton: {
    flex: 1,
    backgroundColor: '#2563EB',
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    paddingVertical: 12,
    borderRadius: 8,
  },
  actionButtonText: {
    color: '#FFFFFF',
    fontSize: 14,
    fontWeight: '600',
    marginLeft: 8,
  },
  ordersSection: {
    flex: 1,
    paddingHorizontal: 16,
  },
  sectionTitle: {
    fontSize: 18,
    fontWeight: '600',
    color: '#1F2937',
    marginBottom: 12,
  },
  ordersList: {
    flex: 1,
  },
  orderItem: {
    backgroundColor: '#FFFFFF',
    padding: 16,
    borderRadius: 12,
    marginBottom: 8,
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.1,
    shadowRadius: 4,
    elevation: 2,
  },
  orderInfo: {
    flex: 1,
  },
  customerName: {
    fontSize: 16,
    fontWeight: '600',
    color: '#1F2937',
    marginBottom: 4,
  },
  orderAmount: {
    fontSize: 14,
    color: '#6B7280',
  },
  orderActions: {
    alignItems: 'flex-end',
  },
  statusBadge: {
    paddingHorizontal: 8,
    paddingVertical: 4,
    borderRadius: 12,
    marginBottom: 8,
  },
  statusText: {
    color: '#FFFFFF',
    fontSize: 12,
    fontWeight: '600',
  },
  updateButton: {
    backgroundColor: '#10B981',
    paddingHorizontal: 12,
    paddingVertical: 6,
    borderRadius: 6,
  },
  updateButtonText: {
    color: '#FFFFFF',
    fontSize: 12,
    fontWeight: '600',
  },
  errorText: {
    fontSize: 18,
    color: '#EF4444',
    textAlign: 'center',
    marginTop: 50,
  },
});