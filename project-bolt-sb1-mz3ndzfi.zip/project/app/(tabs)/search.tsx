import React, { useState, useEffect } from 'react';
import { View, Text, StyleSheet, TouchableOpacity } from 'react-native';
import { useRouter, useLocalSearchParams } from 'expo-router';
import SearchBar from '@/components/SearchBar';
import ProductGrid from '@/components/ProductGrid';
import FilterModal from '@/components/FilterModal';
import EmptyState from '@/components/EmptyState';
import Toast from '@/components/Toast';
import { useToast } from '@/hooks/useToast';
import { products } from '@/data/mockData';
import { Filter, Search } from 'lucide-react-native';

interface FilterOptions {
  categories: string[];
  priceRange: { min: number; max: number };
  rating: number;
  sortBy: 'price-low' | 'price-high' | 'rating' | 'newest';
}

export default function SearchScreen() {
  const [searchQuery, setSearchQuery] = useState('');
  const [filteredProducts, setFilteredProducts] = useState(products);
  const [showFilters, setShowFilters] = useState(false);
  const [filters, setFilters] = useState<FilterOptions>({
    categories: [],
    priceRange: { min: 0, max: 1000 },
    rating: 0,
    sortBy: 'newest',
  });
  const router = useRouter();
  const params = useLocalSearchParams();
  const { toast, showToast, hideToast } = useToast();

  useEffect(() => {
    if (params.category) {
      setFilters(prev => ({ ...prev, categories: [params.category as string] }));
    }
  }, [params.category]);

  useEffect(() => {
    let filtered = products;

    // Apply search query
    if (searchQuery) {
      filtered = filtered.filter(product =>
        product.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
        product.description.toLowerCase().includes(searchQuery.toLowerCase()) ||
        product.tags.some(tag => tag.toLowerCase().includes(searchQuery.toLowerCase()))
      );
    }

    // Apply category filter
    if (filters.categories.length > 0) {
      filtered = filtered.filter(product => 
        filters.categories.includes(product.category)
      );
    }

    // Apply rating filter
    if (filters.rating > 0) {
      filtered = filtered.filter(product => product.rating >= filters.rating);
    }

    // Apply price range filter
    filtered = filtered.filter(product => 
      product.price >= filters.priceRange.min && 
      product.price <= filters.priceRange.max
    );

    // Apply sorting
    switch (filters.sortBy) {
      case 'price-low':
        filtered.sort((a, b) => a.price - b.price);
        break;
      case 'price-high':
        filtered.sort((a, b) => b.price - a.price);
        break;
      case 'rating':
        filtered.sort((a, b) => b.rating - a.rating);
        break;
      case 'newest':
        // Assuming newer products have higher IDs
        filtered.sort((a, b) => parseInt(b.id) - parseInt(a.id));
        break;
    }

    setFilteredProducts(filtered);
  }, [searchQuery, filters]);

  const handleProductPress = (productId: string) => {
    router.push(`/product/${productId}`);
  };

  const handleApplyFilters = (newFilters: FilterOptions) => {
    setFilters(newFilters);
    showToast('success', 'Filters applied successfully');
  };

  const getActiveFilterCount = () => {
    let count = 0;
    if (filters.categories.length > 0) count++;
    if (filters.rating > 0) count++;
    if (filters.sortBy !== 'newest') count++;
    return count;
  };

  return (
    <View style={styles.container}>
      <Toast
        type={toast.type}
        message={toast.message}
        visible={toast.visible}
        onHide={hideToast}
      />
      
      <View style={styles.header}>
        <Text style={styles.title}>Search Products</Text>
        <SearchBar
          value={searchQuery}
          onChangeText={setSearchQuery}
          placeholder="Search for products..."
        />
        
        <View style={styles.filterRow}>
          <TouchableOpacity
            style={[styles.filterButton, getActiveFilterCount() > 0 && styles.filterButtonActive]}
            onPress={() => setShowFilters(true)}
          >
            <Filter size={20} color={getActiveFilterCount() > 0 ? '#FFFFFF' : '#6B7280'} />
            <Text style={[
              styles.filterButtonText,
              getActiveFilterCount() > 0 && styles.filterButtonTextActive
            ]}>
              Filters
            </Text>
            {getActiveFilterCount() > 0 && (
              <View style={styles.filterBadge}>
                <Text style={styles.filterBadgeText}>{getActiveFilterCount()}</Text>
              </View>
            )}
          </TouchableOpacity>
          
          <Text style={styles.resultsText}>
            {filteredProducts.length} products found
          </Text>
        </View>
      </View>

      {filteredProducts.length === 0 ? (
        <EmptyState
          icon={Search}
          title="No products found"
          subtitle="Try adjusting your search or filters to find what you're looking for"
          buttonText="Clear Filters"
          onButtonPress={() => {
            setFilters({
              categories: [],
              priceRange: { min: 0, max: 1000 },
              rating: 0,
              sortBy: 'newest',
            });
            setSearchQuery('');
          }}
        />
      ) : (
        <ProductGrid
          products={filteredProducts}
          onProductPress={handleProductPress}
          numColumns={2}
        />
      )}

      <FilterModal
        visible={showFilters}
        onClose={() => setShowFilters(false)}
        onApply={handleApplyFilters}
        initialFilters={filters}
      />
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#F9FAFB',
  },
  header: {
    paddingTop: 60,
    paddingBottom: 20,
    backgroundColor: '#FFFFFF',
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.1,
    shadowRadius: 4,
    elevation: 3,
  },
  title: {
    fontSize: 24,
    fontWeight: '700',
    color: '#1F2937',
    textAlign: 'center',
    marginBottom: 16,
  },
  filterRow: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    paddingHorizontal: 16,
    marginTop: 16,
  },
  filterButton: {
    flexDirection: 'row',
    alignItems: 'center',
    paddingHorizontal: 16,
    paddingVertical: 8,
    backgroundColor: '#F3F4F6',
    borderRadius: 20,
    position: 'relative',
  },
  filterButtonActive: {
    backgroundColor: '#2563EB',
  },
  filterButtonText: {
    fontSize: 14,
    color: '#6B7280',
    fontWeight: '500',
    marginLeft: 8,
  },
  filterButtonTextActive: {
    color: '#FFFFFF',
  },
  filterBadge: {
    position: 'absolute',
    top: -4,
    right: -4,
    backgroundColor: '#EF4444',
    borderRadius: 10,
    width: 20,
    height: 20,
    justifyContent: 'center',
    alignItems: 'center',
  },
  filterBadgeText: {
    color: '#FFFFFF',
    fontSize: 12,
    fontWeight: '600',
  },
  resultsText: {
    fontSize: 14,
    color: '#6B7280',
  },
});