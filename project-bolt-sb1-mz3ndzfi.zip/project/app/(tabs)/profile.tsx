import React from 'react';
import { View, Text, StyleSheet, TouchableOpacity, ScrollView, Platform } from 'react-native';
import { useRouter } from 'expo-router';
import { useAuth } from '@/context/AuthContext';
import { useTheme } from '@/context/ThemeContext';
import { 
  User, 
  Package, 
  Heart, 
  Settings, 
  LogOut, 
  Shield, 
  Mail, 
  Star, 
  Gift, 
  Users, 
  Eye, 
  Search,
  CreditCard,
  MapPin,
  ChevronRight,
  Bell
} from 'lucide-react-native';

export default function ProfileScreen() {
  const { user, logout } = useAuth();
  const { colors } = useTheme();
  const router = useRouter();

  const handleLogout = () => {
    logout();
    router.replace('/(auth)/login');
  };

  const accountMenuItems = [
    { 
      icon: Package, 
      label: 'Orders', 
      onPress: () => router.push('/(tabs)/orders'),
      description: 'Track, return and buy things again'
    },
    { 
      icon: Mail, 
      label: 'Inbox', 
      onPress: () => {},
      description: 'Messages, order updates and more'
    },
    { 
      icon: Star, 
      label: 'Ratings & Reviews', 
      onPress: () => {},
      description: 'Rate products and view your reviews'
    },
    { 
      icon: Gift, 
      label: 'Vouchers', 
      onPress: () => {},
      description: 'View available vouchers and discounts'
    },
    { 
      icon: Heart, 
      label: 'Wishlist', 
      onPress: () => router.push('/(tabs)/wishlist'),
      description: 'Your saved items'
    },
    { 
      icon: Users, 
      label: 'Followed Sellers', 
      onPress: () => {},
      description: 'Manage your followed sellers'
    },
    { 
      icon: Eye, 
      label: 'Recently Viewed', 
      onPress: () => {},
      description: 'View your browsing history'
    },
    { 
      icon: Search, 
      label: 'Recently Searched', 
      onPress: () => {},
      description: 'Your recent search history'
    },
  ];

  const settingsMenuItems = [
    { 
      icon: CreditCard, 
      label: 'Payment Settings', 
      onPress: () => {},
      description: 'Manage payment methods'
    },
    { 
      icon: MapPin, 
      label: 'Address Book', 
      onPress: () => {},
      description: 'Manage delivery addresses'
    },
    { 
      icon: Bell, 
      label: 'Notifications', 
      onPress: () => {},
      description: 'Manage notification preferences'
    },
    { 
      icon: Settings, 
      label: 'Account Settings', 
      onPress: () => {},
      description: 'Privacy, security and more'
    },
  ];

  const styles = createStyles(colors);

  return (
    <ScrollView style={styles.container} showsVerticalScrollIndicator={false}>
      {/* Header */}
      <View style={styles.header}>
        <View style={styles.loginPrompt}>
          <User size={24} color={colors.primary} />
          <View style={styles.loginText}>
            <Text style={styles.loginTitle}>
              {user ? `Hello, ${user.name}!` : 'Login to see your balance'}
            </Text>
            {user && (
              <Text style={styles.loginSubtitle}>{user.email}</Text>
            )}
          </View>
        </View>
      </View>

      {/* Account Section */}
      <View style={styles.section}>
        <Text style={styles.sectionTitle}>My Account</Text>
        <View style={styles.menuContainer}>
          {accountMenuItems.map((item, index) => (
            <TouchableOpacity
              key={index}
              style={[
                styles.menuItem,
                index === accountMenuItems.length - 1 && styles.lastMenuItem
              ]}
              onPress={item.onPress}
            >
              <View style={styles.menuItemLeft}>
                <View style={styles.menuIcon}>
                  <item.icon size={20} color={colors.textSecondary} />
                </View>
                <View style={styles.menuTextContainer}>
                  <Text style={styles.menuLabel}>{item.label}</Text>
                  {item.description && (
                    <Text style={styles.menuDescription}>{item.description}</Text>
                  )}
                </View>
              </View>
              <ChevronRight size={20} color={colors.textSecondary} />
            </TouchableOpacity>
          ))}
        </View>
      </View>

      {/* Settings Section */}
      <View style={styles.section}>
        <Text style={styles.sectionTitle}>My Settings</Text>
        <View style={styles.menuContainer}>
          {settingsMenuItems.map((item, index) => (
            <TouchableOpacity
              key={index}
              style={[
                styles.menuItem,
                index === settingsMenuItems.length - 1 && styles.lastMenuItem
              ]}
              onPress={item.onPress}
            >
              <View style={styles.menuItemLeft}>
                <View style={styles.menuIcon}>
                  <item.icon size={20} color={colors.textSecondary} />
                </View>
                <View style={styles.menuTextContainer}>
                  <Text style={styles.menuLabel}>{item.label}</Text>
                  {item.description && (
                    <Text style={styles.menuDescription}>{item.description}</Text>
                  )}
                </View>
              </View>
              <ChevronRight size={20} color={colors.textSecondary} />
            </TouchableOpacity>
          ))}
        </View>
      </View>

      {/* Admin Section (if admin) */}
      {user?.role === 'admin' && (
        <View style={styles.section}>
          <Text style={styles.sectionTitle}>Admin Panel</Text>
          <View style={styles.menuContainer}>
            <TouchableOpacity
              style={styles.menuItem}
              onPress={() => router.push('/(tabs)/admin')}
            >
              <View style={styles.menuItemLeft}>
                <View style={styles.menuIcon}>
                  <Shield size={20} color={colors.primary} />
                </View>
                <View style={styles.menuTextContainer}>
                  <Text style={[styles.menuLabel, { color: colors.primary }]}>Admin Dashboard</Text>
                  <Text style={styles.menuDescription}>Manage products, orders and users</Text>
                </View>
              </View>
              <ChevronRight size={20} color={colors.primary} />
            </TouchableOpacity>
          </View>
        </View>
      )}

      {/* Logout Button */}
      {user && (
        <TouchableOpacity style={styles.logoutButton} onPress={handleLogout}>
          <LogOut size={20} color={colors.error} />
          <Text style={styles.logoutText}>Logout</Text>
        </TouchableOpacity>
      )}

      {/* Bottom Spacing */}
      <View style={styles.bottomSpacing} />
    </ScrollView>
  );
}

const createStyles = (colors: any) => StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: colors.background,
  },
  header: {
    backgroundColor: colors.card,
    paddingTop: Platform.OS === 'web' ? 40 : 60,
    paddingBottom: 20,
    paddingHorizontal: 20,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.1,
    shadowRadius: 4,
    elevation: 3,
    borderBottomWidth: 1,
    borderBottomColor: colors.border,
  },
  loginPrompt: {
    flexDirection: 'row',
    alignItems: 'center',
  },
  loginText: {
    marginLeft: 12,
    flex: 1,
  },
  loginTitle: {
    fontSize: 18,
    fontWeight: '600',
    color: colors.text,
    marginBottom: 2,
  },
  loginSubtitle: {
    fontSize: 14,
    color: colors.textSecondary,
  },
  section: {
    marginTop: 24,
  },
  sectionTitle: {
    fontSize: 16,
    fontWeight: '600',
    color: colors.textSecondary,
    marginBottom: 12,
    marginLeft: 20,
    textTransform: 'uppercase',
    letterSpacing: 0.5,
  },
  menuContainer: {
    backgroundColor: colors.card,
    marginHorizontal: 0,
    borderTopWidth: 1,
    borderBottomWidth: 1,
    borderColor: colors.border,
  },
  menuItem: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    paddingVertical: 16,
    paddingHorizontal: 20,
    borderBottomWidth: 1,
    borderBottomColor: colors.border,
    backgroundColor: colors.card,
  },
  lastMenuItem: {
    borderBottomWidth: 0,
  },
  menuItemLeft: {
    flexDirection: 'row',
    alignItems: 'center',
    flex: 1,
  },
  menuIcon: {
    width: 24,
    height: 24,
    justifyContent: 'center',
    alignItems: 'center',
    marginRight: 16,
  },
  menuTextContainer: {
    flex: 1,
  },
  menuLabel: {
    fontSize: 16,
    color: colors.text,
    fontWeight: '500',
    marginBottom: 2,
  },
  menuDescription: {
    fontSize: 13,
    color: colors.textSecondary,
    lineHeight: 18,
  },
  logoutButton: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    backgroundColor: colors.card,
    marginHorizontal: 20,
    marginTop: 24,
    borderRadius: 12,
    paddingVertical: 16,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.1,
    shadowRadius: 4,
    elevation: 2,
    borderWidth: 1,
    borderColor: colors.border,
  },
  logoutText: {
    fontSize: 16,
    color: colors.error,
    fontWeight: '600',
    marginLeft: 8,
  },
  bottomSpacing: {
    height: 100,
  },
});