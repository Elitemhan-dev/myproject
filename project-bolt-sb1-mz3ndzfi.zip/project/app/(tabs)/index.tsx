import React, { useState } from 'react';
import { View, Text, ScrollView, StyleSheet, TouchableOpacity, FlatList, Image, Dimensions } from 'react-native';
import { useRouter } from 'expo-router';
import { useAuth } from '@/context/AuthContext';
import { useTheme } from '@/context/ThemeContext';
import SearchBar from '@/components/SearchBar';
import ProductCard from '@/components/ProductCard';
import CategoryCard from '@/components/CategoryCard';
import { categories, featuredProducts, bestSellers } from '@/data/mockData';
import { Smartphone, Shirt, Chrome as Home, Dumbbell, Book, Heart, Bell, ShoppingCart } from 'lucide-react-native';

const { width } = Dimensions.get('window');

const iconMap = {
  smartphone: Smartphone,
  shirt: Shirt,
  home: Home,
  dumbbell: Dumbbell,
  book: Book,
  heart: Heart,
};

// Flash sale items with countdown
const flashSaleItems = [
  {
    id: 'flash1',
    name: 'Solar LED Outdoor Garden Light',
    price: 99.00,
    originalPrice: 197.01,
    discount: 50,
    image: 'https://images.pexels.com/photos/1108572/pexels-photo-1108572.jpeg?auto=compress&cs=tinysrgb&w=400',
    timeLeft: '17 items left'
  },
  {
    id: 'flash2',
    name: 'ASHION Chunky Platform Sneakers',
    price: 99.00,
    originalPrice: 136.95,
    discount: 28,
    image: 'https://images.pexels.com/photos/2529148/pexels-photo-2529148.jpeg?auto=compress&cs=tinysrgb&w=400',
    timeLeft: '6 items left'
  },
  {
    id: 'flash3',
    name: 'Women\'s Fashion Dress',
    price: 55.00,
    originalPrice: 89.00,
    discount: 38,
    image: 'https://images.pexels.com/photos/985635/pexels-photo-985635.jpeg?auto=compress&cs=tinysrgb&w=400',
    timeLeft: '9 items left'
  },
];

// Sponsored categories
const sponsoredCategories = [
  { id: '1', name: 'Jumia Global', color: '#0066CC', image: 'https://images.pexels.com/photos/3184291/pexels-photo-3184291.jpeg?auto=compress&cs=tinysrgb&w=200' },
  { id: '2', name: 'Donkomi Sales', color: '#FF6B35', image: 'https://images.pexels.com/photos/230544/pexels-photo-230544.jpeg?auto=compress&cs=tinysrgb&w=200' },
  { id: '3', name: 'Kumasi Marketplace', color: '#8B4513', image: 'https://images.pexels.com/photos/1005638/pexels-photo-1005638.jpeg?auto=compress&cs=tinysrgb&w=200' },
  { id: '4', name: 'Discount @Checkout', color: '#FFD700', image: 'https://images.pexels.com/photos/230544/pexels-photo-230544.jpeg?auto=compress&cs=tinysrgb&w=200' },
  { id: '5', name: 'New this Week', color: '#FF4500', image: 'https://images.pexels.com/photos/3394650/pexels-photo-3394650.jpeg?auto=compress&cs=tinysrgb&w=200' },
  { id: '6', name: 'Official Store', color: '#32CD32', image: 'https://images.pexels.com/photos/788946/pexels-photo-788946.jpeg?auto=compress&cs=tinysrgb&w=200' },
  { id: '7', name: 'Trending Now', color: '#FF1493', image: 'https://images.pexels.com/photos/1040880/pexels-photo-1040880.jpeg?auto=compress&cs=tinysrgb&w=200' },
  { id: '8', name: 'Beauty', color: '#FF69B4', image: 'https://images.pexels.com/photos/3018845/pexels-photo-3018845.jpeg?auto=compress&cs=tinysrgb&w=200' },
];

export default function HomeScreen() {
  const [searchQuery, setSearchQuery] = useState('');
  const { user } = useAuth();
  const { colors } = useTheme();
  const router = useRouter();

  const handleProductPress = (productId: string) => {
    router.push(`/product/${productId}`);
  };

  const handleCategoryPress = (categoryName: string) => {
    router.push(`/search?category=${categoryName}`);
  };

  const styles = createStyles(colors, width);

  return (
    <ScrollView style={styles.container} showsVerticalScrollIndicator={false}>
      {/* Header */}
      <View style={styles.header}>
        <View style={styles.headerTop}>
          <View style={styles.greeting}>
            <Text style={styles.greetingText}>Hello, {user?.name || 'Guest'}!</Text>
            <Text style={styles.subtitle}>What are you looking for today?</Text>
          </View>
          <TouchableOpacity style={styles.notificationButton}>
            <Bell size={24} color={colors.text} />
          </TouchableOpacity>
        </View>
        
        <SearchBar
          value={searchQuery}
          onChangeText={setSearchQuery}
          placeholder="Search on Jumia"
        />
      </View>

      {/* Flash Sale Section */}
      <View style={styles.flashSaleSection}>
        <View style={styles.flashSaleHeader}>
          <Text style={styles.flashSaleTitle}>Flash Sales</Text>
          <TouchableOpacity>
            <Text style={styles.seeAll}>SEE ALL</Text>
          </TouchableOpacity>
        </View>
        
        <View style={styles.flashSaleCountdown}>
          {flashSaleItems.map((item, index) => (
            <View key={item.id} style={styles.countdownItem}>
              <Text style={styles.countdownText}>{item.timeLeft}</Text>
              <View style={styles.progressBar}>
                <View style={[styles.progressFill, { width: `${Math.random() * 100}%` }]} />
              </View>
            </View>
          ))}
        </View>

        <FlatList
          horizontal
          data={flashSaleItems}
          renderItem={({ item }) => (
            <TouchableOpacity style={styles.flashSaleItem}>
              <Image source={{ uri: item.image }} style={styles.flashSaleImage} />
              <View style={styles.discountBadge}>
                <Text style={styles.discountText}>-{item.discount}%</Text>
              </View>
              <View style={styles.flashSaleInfo}>
                <Text style={styles.flashSalePrice}>GH₵ {item.price.toFixed(2)}</Text>
                <Text style={styles.flashSaleOriginalPrice}>GH₵ {item.originalPrice.toFixed(2)}</Text>
              </View>
            </TouchableOpacity>
          )}
          keyExtractor={(item) => item.id}
          showsHorizontalScrollIndicator={false}
          contentContainerStyle={styles.flashSaleList}
        />
      </View>

      {/* Sponsored Categories Grid */}
      <View style={styles.sponsoredSection}>
        <Text style={styles.sponsoredTitle}>Sponsored Products</Text>
        <View style={styles.sponsoredGrid}>
          {sponsoredCategories.map((category, index) => (
            <TouchableOpacity 
              key={category.id} 
              style={[styles.sponsoredItem, { backgroundColor: category.color }]}
              onPress={() => handleCategoryPress(category.name)}
            >
              <Image source={{ uri: category.image }} style={styles.sponsoredImage} />
              <Text style={styles.sponsoredText}>{category.name}</Text>
            </TouchableOpacity>
          ))}
        </View>
      </View>

      {/* Categories Section */}
      <View style={styles.section}>
        <Text style={styles.sectionTitle}>Categories</Text>
        <FlatList
          horizontal
          data={categories}
          renderItem={({ item }) => {
            const IconComponent = iconMap[item.icon as keyof typeof iconMap];
            return (
              <CategoryCard
                category={item}
                onPress={() => handleCategoryPress(item.name)}
                Icon={IconComponent}
              />
            );
          }}
          keyExtractor={(item) => item.id}
          showsHorizontalScrollIndicator={false}
          contentContainerStyle={styles.categoriesContainer}
        />
      </View>

      {/* We Saved These For You Section */}
      <View style={styles.section}>
        <View style={styles.sectionHeader}>
          <Text style={styles.sectionTitle}>WE SAVED THESE FOR YOU</Text>
          <TouchableOpacity>
            <Text style={styles.seeAll}>SEE ALL</Text>
          </TouchableOpacity>
        </View>
        <FlatList
          horizontal
          data={featuredProducts.slice(0, 2)}
          renderItem={({ item }) => (
            <TouchableOpacity style={styles.savedItem}>
              <Image source={{ uri: item.image }} style={styles.savedImage} />
              <View style={styles.savedDiscountBadge}>
                <Text style={styles.savedDiscountText}>-43%</Text>
              </View>
              <View style={styles.savedInfo}>
                <Text style={styles.savedPrice}>GH₵ {item.price.toFixed(2)}</Text>
                <Text style={styles.savedOriginalPrice}>GH₵ {(item.price * 1.75).toFixed(2)}</Text>
              </View>
            </TouchableOpacity>
          )}
          keyExtractor={(item) => item.id}
          showsHorizontalScrollIndicator={false}
          contentContainerStyle={styles.savedList}
        />
      </View>

      {/* Featured Products */}
      <View style={styles.section}>
        <View style={styles.sectionHeader}>
          <Text style={styles.sectionTitle}>Featured Products</Text>
          <TouchableOpacity>
            <Text style={styles.seeAll}>See All</Text>
          </TouchableOpacity>
        </View>
        <FlatList
          horizontal
          data={featuredProducts}
          renderItem={({ item }) => (
            <View style={styles.productCard}>
              <ProductCard
                product={item}
                onPress={() => handleProductPress(item.id)}
              />
            </View>
          )}
          keyExtractor={(item) => item.id}
          showsHorizontalScrollIndicator={false}
          contentContainerStyle={styles.productsContainer}
        />
      </View>

      {/* Best Sellers */}
      <View style={styles.section}>
        <View style={styles.sectionHeader}>
          <Text style={styles.sectionTitle}>Best Sellers</Text>
          <TouchableOpacity>
            <Text style={styles.seeAll}>See All</Text>
          </TouchableOpacity>
        </View>
        <FlatList
          horizontal
          data={bestSellers}
          renderItem={({ item }) => (
            <View style={styles.productCard}>
              <ProductCard
                product={item}
                onPress={() => handleProductPress(item.id)}
              />
            </View>
          )}
          keyExtractor={(item) => item.id}
          showsHorizontalScrollIndicator={false}
          contentContainerStyle={styles.productsContainer}
        />
      </View>

      {/* Bottom Spacing */}
      <View style={styles.bottomSpacing} />
    </ScrollView>
  );
}

const createStyles = (colors: any, screenWidth: number) => StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: colors.background,
  },
  header: {
    backgroundColor: colors.card,
    paddingTop: 60,
    paddingBottom: 16,
    paddingHorizontal: 16,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.1,
    shadowRadius: 4,
    elevation: 3,
    borderBottomWidth: 1,
    borderBottomColor: colors.border,
  },
  headerTop: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: 16,
  },
  greeting: {
    flex: 1,
  },
  greetingText: {
    fontSize: 20,
    fontWeight: '600',
    color: colors.text,
    marginBottom: 4,
  },
  subtitle: {
    fontSize: 14,
    color: colors.textSecondary,
  },
  notificationButton: {
    padding: 8,
  },
  flashSaleSection: {
    backgroundColor: colors.card,
    marginTop: 8,
    paddingVertical: 16,
    borderBottomWidth: 1,
    borderBottomColor: colors.border,
  },
  flashSaleHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    paddingHorizontal: 16,
    marginBottom: 12,
  },
  flashSaleTitle: {
    fontSize: 18,
    fontWeight: '700',
    color: colors.text,
  },
  seeAll: {
    fontSize: 14,
    color: colors.primary,
    fontWeight: '600',
  },
  flashSaleCountdown: {
    flexDirection: 'row',
    paddingHorizontal: 16,
    marginBottom: 16,
  },
  countdownItem: {
    flex: 1,
    marginRight: 12,
  },
  countdownText: {
    fontSize: 12,
    color: colors.textSecondary,
    marginBottom: 4,
  },
  progressBar: {
    height: 4,
    backgroundColor: colors.border,
    borderRadius: 2,
    overflow: 'hidden',
  },
  progressFill: {
    height: '100%',
    backgroundColor: colors.warning,
    borderRadius: 2,
  },
  flashSaleList: {
    paddingHorizontal: 16,
  },
  flashSaleItem: {
    width: 140,
    marginRight: 12,
    backgroundColor: colors.surface,
    borderRadius: 8,
    overflow: 'hidden',
    borderWidth: 1,
    borderColor: colors.border,
  },
  flashSaleImage: {
    width: '100%',
    height: 120,
    resizeMode: 'cover',
  },
  discountBadge: {
    position: 'absolute',
    top: 8,
    left: 8,
    backgroundColor: '#FF6B35',
    paddingHorizontal: 6,
    paddingVertical: 2,
    borderRadius: 4,
  },
  discountText: {
    color: '#FFFFFF',
    fontSize: 10,
    fontWeight: '600',
  },
  flashSaleInfo: {
    padding: 8,
  },
  flashSalePrice: {
    fontSize: 14,
    fontWeight: '700',
    color: colors.text,
  },
  flashSaleOriginalPrice: {
    fontSize: 12,
    color: colors.textSecondary,
    textDecorationLine: 'line-through',
  },
  sponsoredSection: {
    backgroundColor: colors.card,
    paddingVertical: 16,
    marginTop: 8,
    borderBottomWidth: 1,
    borderBottomColor: colors.border,
  },
  sponsoredTitle: {
    fontSize: 18,
    fontWeight: '700',
    color: colors.text,
    paddingHorizontal: 16,
    marginBottom: 16,
  },
  sponsoredGrid: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    paddingHorizontal: 8,
  },
  sponsoredItem: {
    width: (screenWidth - 48) / 4,
    height: 80,
    margin: 4,
    borderRadius: 8,
    justifyContent: 'center',
    alignItems: 'center',
    position: 'relative',
    overflow: 'hidden',
  },
  sponsoredImage: {
    position: 'absolute',
    width: '100%',
    height: '100%',
    opacity: 0.3,
  },
  sponsoredText: {
    color: '#FFFFFF',
    fontSize: 10,
    fontWeight: '600',
    textAlign: 'center',
    paddingHorizontal: 4,
    zIndex: 1,
  },
  section: {
    marginTop: 24,
    marginBottom: 16,
  },
  sectionHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    paddingHorizontal: 16,
    marginBottom: 16,
  },
  sectionTitle: {
    fontSize: 18,
    fontWeight: '700',
    color: colors.text,
  },
  categoriesContainer: {
    paddingHorizontal: 16,
  },
  productsContainer: {
    paddingHorizontal: 16,
  },
  productCard: {
    width: 200,
    marginRight: 16,
  },
  savedList: {
    paddingHorizontal: 16,
  },
  savedItem: {
    width: 160,
    marginRight: 12,
    backgroundColor: colors.surface,
    borderRadius: 8,
    overflow: 'hidden',
    borderWidth: 1,
    borderColor: colors.border,
  },
  savedImage: {
    width: '100%',
    height: 140,
    resizeMode: 'cover',
  },
  savedDiscountBadge: {
    position: 'absolute',
    top: 8,
    left: 8,
    backgroundColor: '#FF6B35',
    paddingHorizontal: 6,
    paddingVertical: 2,
    borderRadius: 4,
  },
  savedDiscountText: {
    color: '#FFFFFF',
    fontSize: 10,
    fontWeight: '600',
  },
  savedInfo: {
    padding: 8,
  },
  savedPrice: {
    fontSize: 14,
    fontWeight: '700',
    color: colors.text,
  },
  savedOriginalPrice: {
    fontSize: 12,
    color: colors.textSecondary,
    textDecorationLine: 'line-through',
  },
  bottomSpacing: {
    height: 100,
  },
});