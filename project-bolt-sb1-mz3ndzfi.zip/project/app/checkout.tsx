import React, { useState } from 'react';
import { View, Text, StyleSheet, TouchableOpacity, TextInput, ScrollView, Alert, Linking } from 'react-native';
import { useRouter } from 'expo-router';
import { useCart } from '@/context/CartContext';
import { useOrders } from '@/context/OrderContext';
import { useTheme } from '@/context/ThemeContext';
import { ArrowLeft, MapPin, CreditCard, Truck, MessageCircle } from 'lucide-react-native';

export default function CheckoutScreen() {
  const [deliveryInfo, setDeliveryInfo] = useState({
    fullName: '',
    address: '',
    city: '',
    state: '',
    zipCode: '',
    phone: '',
  });
  const [paymentMethod, setPaymentMethod] = useState('cod');
  const { items, getTotalPrice, clearCart } = useCart();
  const { createOrder } = useOrders();
  const { colors } = useTheme();
  const router = useRouter();

  const handlePlaceOrder = () => {
    if (!deliveryInfo.fullName || !deliveryInfo.address || !deliveryInfo.city || !deliveryInfo.phone) {
      Alert.alert('Error', 'Please fill in all required fields');
      return;
    }

    const orderId = createOrder(items, finalTotal, deliveryInfo);

    Alert.alert(
      'Order Placed!',
      `Your order #${orderId} has been placed successfully. You will receive a confirmation email shortly.`,
      [
        {
          text: 'Track Order',
          onPress: () => {
            clearCart();
            router.replace(`/order/${orderId}`);
          },
        },
        {
          text: 'Continue Shopping',
          onPress: () => {
            clearCart();
            router.replace('/(tabs)');
          },
        },
      ]
    );
  };

  const handleWhatsAppSupport = () => {
    const message = `Hi! I need help with my order. Order total: $${finalTotal.toFixed(2)}`;
    const whatsappUrl = `https://wa.me/1234567890?text=${encodeURIComponent(message)}`;
    Linking.openURL(whatsappUrl);
  };

  const totalPrice = getTotalPrice();
  const deliveryFee = 5.99;
  const tax = totalPrice * 0.08;
  const finalTotal = totalPrice + deliveryFee + tax;

  const styles = createStyles(colors);

  return (
    <ScrollView style={styles.container}>
      <View style={styles.header}>
        <TouchableOpacity style={styles.backButton} onPress={() => router.back()}>
          <ArrowLeft size={24} color={colors.text} />
        </TouchableOpacity>
        <Text style={styles.title}>Checkout</Text>
        <TouchableOpacity style={styles.supportButton} onPress={handleWhatsAppSupport}>
          <MessageCircle size={24} color={colors.primary} />
        </TouchableOpacity>
      </View>

      <View style={styles.section}>
        <View style={styles.sectionHeader}>
          <MapPin size={20} color={colors.primary} />
          <Text style={styles.sectionTitle}>Delivery Address</Text>
        </View>
        <View style={styles.form}>
          <TextInput
            style={styles.input}
            placeholder="Full Name *"
            placeholderTextColor={colors.textSecondary}
            value={deliveryInfo.fullName}
            onChangeText={(text) => setDeliveryInfo({...deliveryInfo, fullName: text})}
          />
          <TextInput
            style={styles.input}
            placeholder="Address *"
            placeholderTextColor={colors.textSecondary}
            value={deliveryInfo.address}
            onChangeText={(text) => setDeliveryInfo({...deliveryInfo, address: text})}
          />
          <View style={styles.row}>
            <TextInput
              style={[styles.input, styles.halfInput]}
              placeholder="City *"
              placeholderTextColor={colors.textSecondary}
              value={deliveryInfo.city}
              onChangeText={(text) => setDeliveryInfo({...deliveryInfo, city: text})}
            />
            <TextInput
              style={[styles.input, styles.halfInput]}
              placeholder="State"
              placeholderTextColor={colors.textSecondary}
              value={deliveryInfo.state}
              onChangeText={(text) => setDeliveryInfo({...deliveryInfo, state: text})}
            />
          </View>
          <View style={styles.row}>
            <TextInput
              style={[styles.input, styles.halfInput]}
              placeholder="ZIP Code"
              placeholderTextColor={colors.textSecondary}
              value={deliveryInfo.zipCode}
              onChangeText={(text) => setDeliveryInfo({...deliveryInfo, zipCode: text})}
            />
            <TextInput
              style={[styles.input, styles.halfInput]}
              placeholder="Phone *"
              placeholderTextColor={colors.textSecondary}
              value={deliveryInfo.phone}
              onChangeText={(text) => setDeliveryInfo({...deliveryInfo, phone: text})}
              keyboardType="phone-pad"
            />
          </View>
        </View>
      </View>

      <View style={styles.section}>
        <View style={styles.sectionHeader}>
          <CreditCard size={20} color={colors.primary} />
          <Text style={styles.sectionTitle}>Payment Method</Text>
        </View>
        <TouchableOpacity
          style={[styles.paymentOption, paymentMethod === 'cod' && styles.paymentOptionActive]}
          onPress={() => setPaymentMethod('cod')}
        >
          <View style={styles.paymentInfo}>
            <Truck size={20} color={colors.textSecondary} />
            <Text style={styles.paymentText}>Cash on Delivery</Text>
          </View>
          <View style={[styles.radio, paymentMethod === 'cod' && styles.radioActive]} />
        </TouchableOpacity>
      </View>

      <View style={styles.section}>
        <Text style={styles.sectionTitle}>Order Summary</Text>
        <View style={styles.summaryRow}>
          <Text style={styles.summaryLabel}>Subtotal ({items.length} items)</Text>
          <Text style={styles.summaryValue}>${totalPrice.toFixed(2)}</Text>
        </View>
        <View style={styles.summaryRow}>
          <Text style={styles.summaryLabel}>Delivery Fee</Text>
          <Text style={styles.summaryValue}>${deliveryFee.toFixed(2)}</Text>
        </View>
        <View style={styles.summaryRow}>
          <Text style={styles.summaryLabel}>Tax</Text>
          <Text style={styles.summaryValue}>${tax.toFixed(2)}</Text>
        </View>
        <View style={[styles.summaryRow, styles.totalRow]}>
          <Text style={styles.totalLabel}>Total</Text>
          <Text style={styles.totalValue}>${finalTotal.toFixed(2)}</Text>
        </View>
      </View>

      <TouchableOpacity style={styles.placeOrderButton} onPress={handlePlaceOrder}>
        <Text style={styles.placeOrderText}>Place Order</Text>
      </TouchableOpacity>
    </ScrollView>
  );
}

const createStyles = (colors: any) => StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: colors.background,
  },
  header: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    paddingTop: 60,
    paddingBottom: 20,
    paddingHorizontal: 20,
    backgroundColor: colors.card,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.1,
    shadowRadius: 4,
    elevation: 3,
  },
  backButton: {
    padding: 4,
  },
  title: {
    fontSize: 20,
    fontWeight: '700',
    color: colors.text,
  },
  supportButton: {
    padding: 4,
  },
  section: {
    backgroundColor: colors.card,
    marginHorizontal: 16,
    marginTop: 16,
    borderRadius: 12,
    padding: 16,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.1,
    shadowRadius: 4,
    elevation: 2,
    borderWidth: 1,
    borderColor: colors.border,
  },
  sectionHeader: {
    flexDirection: 'row',
    alignItems: 'center',
    marginBottom: 16,
  },
  sectionTitle: {
    fontSize: 18,
    fontWeight: '600',
    color: colors.text,
    marginLeft: 8,
  },
  form: {
    gap: 12,
  },
  input: {
    backgroundColor: colors.surface,
    borderRadius: 8,
    paddingHorizontal: 12,
    paddingVertical: 12,
    fontSize: 16,
    color: colors.text,
    borderWidth: 1,
    borderColor: colors.border,
  },
  row: {
    flexDirection: 'row',
    gap: 12,
  },
  halfInput: {
    flex: 1,
  },
  paymentOption: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    paddingVertical: 12,
    paddingHorizontal: 16,
    borderRadius: 8,
    borderWidth: 1,
    borderColor: colors.border,
    backgroundColor: colors.surface,
  },
  paymentOptionActive: {
    borderColor: colors.primary,
    backgroundColor: colors.primary + '10',
  },
  paymentInfo: {
    flexDirection: 'row',
    alignItems: 'center',
  },
  paymentText: {
    fontSize: 16,
    color: colors.text,
    marginLeft: 8,
  },
  radio: {
    width: 20,
    height: 20,
    borderRadius: 10,
    borderWidth: 2,
    borderColor: colors.border,
  },
  radioActive: {
    borderColor: colors.primary,
    backgroundColor: colors.primary,
  },
  summaryRow: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    paddingVertical: 8,
  },
  summaryLabel: {
    fontSize: 14,
    color: colors.textSecondary,
  },
  summaryValue: {
    fontSize: 14,
    color: colors.text,
  },
  totalRow: {
    borderTopWidth: 1,
    borderTopColor: colors.border,
    marginTop: 8,
    paddingTop: 12,
  },
  totalLabel: {
    fontSize: 18,
    fontWeight: '600',
    color: colors.text,
  },
  totalValue: {
    fontSize: 18,
    fontWeight: '700',
    color: colors.primary,
  },
  placeOrderButton: {
    backgroundColor: colors.primary,
    borderRadius: 12,
    paddingVertical: 16,
    alignItems: 'center',
    margin: 16,
    marginBottom: 32,
  },
  placeOrderText: {
    color: '#FFFFFF',
    fontSize: 16,
    fontWeight: '600',
  },
});