export async function GET(request: Request) {
  try {
    const authHeader = request.headers.get('Authorization');
    const user = await verifyToken(authHeader);
    
    if (!user) {
      return new Response(JSON.stringify({ error: 'Unauthorized' }), {
        status: 401,
        headers: { 'Content-Type': 'application/json' }
      });
    }

    const url = new URL(request.url);
    const status = url.searchParams.get('status');
    
    let orders = getStoredOrders();
    
    // Filter by user (customers see only their orders, admins see all)
    if (user.role !== 'admin') {
      orders = orders.filter(order => order.userId === user.userId);
    }
    
    // Filter by status
    if (status) {
      orders = orders.filter(order => order.status === status);
    }
    
    // Sort by creation date (newest first)
    orders.sort((a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime());

    return new Response(JSON.stringify({
      success: true,
      orders
    }), {
      status: 200,
      headers: { 'Content-Type': 'application/json' }
    });

  } catch (error) {
    console.error('Get orders error:', error);
    return new Response(JSON.stringify({ error: 'Internal server error' }), {
      status: 500,
      headers: { 'Content-Type': 'application/json' }
    });
  }
}

export async function POST(request: Request) {
  try {
    const authHeader = request.headers.get('Authorization');
    const user = await verifyToken(authHeader);
    
    if (!user) {
      return new Response(JSON.stringify({ error: 'Unauthorized' }), {
        status: 401,
        headers: { 'Content-Type': 'application/json' }
      });
    }

    const orderData = await request.json();
    
    // Validate required fields
    const requiredFields = ['items', 'total', 'deliveryAddress'];
    for (const field of requiredFields) {
      if (!orderData[field]) {
        return new Response(JSON.stringify({ error: `${field} is required` }), {
          status: 400,
          headers: { 'Content-Type': 'application/json' }
        });
      }
    }

    // Validate items
    if (!Array.isArray(orderData.items) || orderData.items.length === 0) {
      return new Response(JSON.stringify({ error: 'Order must contain at least one item' }), {
        status: 400,
        headers: { 'Content-Type': 'application/json' }
      });
    }

    // Create order
    const order = await createOrder({
      ...orderData,
      userId: user.userId,
      status: 'pending'
    });

    // Update product stock
    await updateProductStock(orderData.items);

    return new Response(JSON.stringify({
      success: true,
      order
    }), {
      status: 201,
      headers: { 'Content-Type': 'application/json' }
    });

  } catch (error) {
    console.error('Create order error:', error);
    return new Response(JSON.stringify({ error: 'Internal server error' }), {
      status: 500,
      headers: { 'Content-Type': 'application/json' }
    });
  }
}

async function createOrder(orderData: any) {
  const orders = getStoredOrders();
  const newOrder = {
    id: `ORD-${Date.now()}`,
    ...orderData,
    createdAt: new Date().toISOString(),
    updatedAt: new Date().toISOString()
  };
  orders.push(newOrder);
  storeOrders(orders);
  return newOrder;
}

async function updateProductStock(items: any[]) {
  const products = getStoredProducts();
  
  for (const item of items) {
    const productIndex = products.findIndex(p => p.id === item.product.id);
    if (productIndex !== -1) {
      products[productIndex].stock = Math.max(0, products[productIndex].stock - item.quantity);
    }
  }
  
  storeProducts(products);
}

async function verifyToken(authHeader: string | null) {
  if (!authHeader || !authHeader.startsWith('Bearer ')) {
    return null;
  }
  
  try {
    const token = authHeader.substring(7);
    const decoded = JSON.parse(atob(token));
    
    if (decoded.exp < Date.now()) {
      return null;
    }
    
    return decoded;
  } catch {
    return null;
  }
}

function getStoredOrders() {
  if (typeof window !== 'undefined') {
    const stored = localStorage.getItem('orders');
    return stored ? JSON.parse(stored) : [];
  }
  return [];
}

function storeOrders(orders: any[]) {
  if (typeof window !== 'undefined') {
    localStorage.setItem('orders', JSON.stringify(orders));
  }
}

function getStoredProducts() {
  if (typeof window !== 'undefined') {
    const stored = localStorage.getItem('products');
    return stored ? JSON.parse(stored) : [];
  }
  return [];
}

function storeProducts(products: any[]) {
  if (typeof window !== 'undefined') {
    localStorage.setItem('products', JSON.stringify(products));
  }
}