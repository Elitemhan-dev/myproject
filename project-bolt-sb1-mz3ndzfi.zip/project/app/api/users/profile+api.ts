export async function GET(request: Request) {
  try {
    const authHeader = request.headers.get('Authorization');
    const user = await verifyToken(authHeader);
    
    if (!user) {
      return new Response(JSON.stringify({ error: 'Unauthorized' }), {
        status: 401,
        headers: { 'Content-Type': 'application/json' }
      });
    }

    const userProfile = await getUserProfile(user.userId);
    
    if (!userProfile) {
      return new Response(JSON.stringify({ error: 'User not found' }), {
        status: 404,
        headers: { 'Content-Type': 'application/json' }
      });
    }

    // Remove sensitive data
    const { password, ...safeProfile } = userProfile;

    return new Response(JSON.stringify({
      success: true,
      user: safeProfile
    }), {
      status: 200,
      headers: { 'Content-Type': 'application/json' }
    });

  } catch (error) {
    console.error('Get profile error:', error);
    return new Response(JSON.stringify({ error: 'Internal server error' }), {
      status: 500,
      headers: { 'Content-Type': 'application/json' }
    });
  }
}

export async function PUT(request: Request) {
  try {
    const authHeader = request.headers.get('Authorization');
    const user = await verifyToken(authHeader);
    
    if (!user) {
      return new Response(JSON.stringify({ error: 'Unauthorized' }), {
        status: 401,
        headers: { 'Content-Type': 'application/json' }
      });
    }

    const updateData = await request.json();
    
    // Remove sensitive fields that shouldn't be updated via this endpoint
    const { password, role, id, ...safeUpdateData } = updateData;
    
    const updatedUser = await updateUserProfile(user.userId, safeUpdateData);
    
    if (!updatedUser) {
      return new Response(JSON.stringify({ error: 'User not found' }), {
        status: 404,
        headers: { 'Content-Type': 'application/json' }
      });
    }

    // Remove sensitive data
    const { password: _, ...safeProfile } = updatedUser;

    return new Response(JSON.stringify({
      success: true,
      user: safeProfile
    }), {
      status: 200,
      headers: { 'Content-Type': 'application/json' }
    });

  } catch (error) {
    console.error('Update profile error:', error);
    return new Response(JSON.stringify({ error: 'Internal server error' }), {
      status: 500,
      headers: { 'Content-Type': 'application/json' }
    });
  }
}

async function getUserProfile(userId: string) {
  const users = getStoredUsers();
  return users.find(user => user.id === userId);
}

async function updateUserProfile(userId: string, updateData: any) {
  const users = getStoredUsers();
  const userIndex = users.findIndex(user => user.id === userId);
  
  if (userIndex === -1) {
    return null;
  }
  
  users[userIndex] = {
    ...users[userIndex],
    ...updateData,
    updatedAt: new Date().toISOString()
  };
  
  storeUsers(users);
  return users[userIndex];
}

async function verifyToken(authHeader: string | null) {
  if (!authHeader || !authHeader.startsWith('Bearer ')) {
    return null;
  }
  
  try {
    const token = authHeader.substring(7);
    const decoded = JSON.parse(atob(token));
    
    if (decoded.exp < Date.now()) {
      return null;
    }
    
    return decoded;
  } catch {
    return null;
  }
}

function getStoredUsers() {
  if (typeof window !== 'undefined') {
    const stored = localStorage.getItem('users');
    return stored ? JSON.parse(stored) : [];
  }
  return [];
}

function storeUsers(users: any[]) {
  if (typeof window !== 'undefined') {
    localStorage.setItem('users', JSON.stringify(users));
  }
}