export async function GET(request: Request) {
  try {
    const authHeader = request.headers.get('Authorization');
    const user = await verifyToken(authHeader);
    
    if (!user || user.role !== 'admin') {
      return new Response(JSON.stringify({ error: 'Unauthorized' }), {
        status: 401,
        headers: { 'Content-Type': 'application/json' }
      });
    }

    const analytics = await getAnalytics();

    return new Response(JSON.stringify({
      success: true,
      analytics
    }), {
      status: 200,
      headers: { 'Content-Type': 'application/json' }
    });

  } catch (error) {
    console.error('Get analytics error:', error);
    return new Response(JSON.stringify({ error: 'Internal server error' }), {
      status: 500,
      headers: { 'Content-Type': 'application/json' }
    });
  }
}

async function getAnalytics() {
  const products = getStoredProducts();
  const orders = getStoredOrders();
  const users = getStoredUsers();
  const reviews = getStoredReviews();

  // Calculate total revenue
  const totalRevenue = orders
    .filter(order => order.status === 'delivered')
    .reduce((sum, order) => sum + order.total, 0);

  // Calculate monthly revenue (last 12 months)
  const monthlyRevenue = [];
  for (let i = 11; i >= 0; i--) {
    const date = new Date();
    date.setMonth(date.getMonth() - i);
    const monthStart = new Date(date.getFullYear(), date.getMonth(), 1);
    const monthEnd = new Date(date.getFullYear(), date.getMonth() + 1, 0);
    
    const monthRevenue = orders
      .filter(order => {
        const orderDate = new Date(order.createdAt);
        return orderDate >= monthStart && orderDate <= monthEnd && order.status === 'delivered';
      })
      .reduce((sum, order) => sum + order.total, 0);
    
    monthlyRevenue.push({
      month: date.toLocaleDateString('en-US', { month: 'short', year: 'numeric' }),
      revenue: monthRevenue
    });
  }

  // Top selling products
  const productSales = {};
  orders.forEach(order => {
    order.items.forEach(item => {
      const productId = item.product.id;
      if (!productSales[productId]) {
        productSales[productId] = {
          product: item.product,
          totalSold: 0,
          revenue: 0
        };
      }
      productSales[productId].totalSold += item.quantity;
      productSales[productId].revenue += item.product.price * item.quantity;
    });
  });

  const topProducts = Object.values(productSales)
    .sort((a: any, b: any) => b.totalSold - a.totalSold)
    .slice(0, 10);

  // Order status distribution
  const orderStatusCounts = orders.reduce((acc, order) => {
    acc[order.status] = (acc[order.status] || 0) + 1;
    return acc;
  }, {});

  // Recent activity
  const recentOrders = orders
    .sort((a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime())
    .slice(0, 10);

  const recentReviews = reviews
    .sort((a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime())
    .slice(0, 10);

  return {
    overview: {
      totalProducts: products.length,
      totalOrders: orders.length,
      totalUsers: users.length,
      totalRevenue,
      averageOrderValue: orders.length > 0 ? totalRevenue / orders.length : 0
    },
    monthlyRevenue,
    topProducts,
    orderStatusCounts,
    recentActivity: {
      orders: recentOrders,
      reviews: recentReviews
    },
    userGrowth: calculateUserGrowth(users),
    categoryPerformance: calculateCategoryPerformance(products, orders)
  };
}

function calculateUserGrowth(users: any[]) {
  const monthlyGrowth = [];
  for (let i = 11; i >= 0; i--) {
    const date = new Date();
    date.setMonth(date.getMonth() - i);
    const monthStart = new Date(date.getFullYear(), date.getMonth(), 1);
    const monthEnd = new Date(date.getFullYear(), date.getMonth() + 1, 0);
    
    const newUsers = users.filter(user => {
      const userDate = new Date(user.createdAt);
      return userDate >= monthStart && userDate <= monthEnd;
    }).length;
    
    monthlyGrowth.push({
      month: date.toLocaleDateString('en-US', { month: 'short', year: 'numeric' }),
      newUsers
    });
  }
  return monthlyGrowth;
}

function calculateCategoryPerformance(products: any[], orders: any[]) {
  const categoryStats = {};
  
  products.forEach(product => {
    if (!categoryStats[product.category]) {
      categoryStats[product.category] = {
        totalProducts: 0,
        totalSold: 0,
        revenue: 0
      };
    }
    categoryStats[product.category].totalProducts++;
  });
  
  orders.forEach(order => {
    order.items.forEach(item => {
      const category = item.product.category;
      if (categoryStats[category]) {
        categoryStats[category].totalSold += item.quantity;
        categoryStats[category].revenue += item.product.price * item.quantity;
      }
    });
  });
  
  return Object.entries(categoryStats).map(([category, stats]) => ({
    category,
    ...stats
  }));
}

async function verifyToken(authHeader: string | null) {
  if (!authHeader || !authHeader.startsWith('Bearer ')) {
    return null;
  }
  
  try {
    const token = authHeader.substring(7);
    const decoded = JSON.parse(atob(token));
    
    if (decoded.exp < Date.now()) {
      return null;
    }
    
    return decoded;
  } catch {
    return null;
  }
}

function getStoredProducts() {
  if (typeof window !== 'undefined') {
    const stored = localStorage.getItem('products');
    return stored ? JSON.parse(stored) : [];
  }
  return [];
}

function getStoredOrders() {
  if (typeof window !== 'undefined') {
    const stored = localStorage.getItem('orders');
    return stored ? JSON.parse(stored) : [];
  }
  return [];
}

function getStoredUsers() {
  if (typeof window !== 'undefined') {
    const stored = localStorage.getItem('users');
    return stored ? JSON.parse(stored) : [];
  }
  return [];
}

function getStoredReviews() {
  if (typeof window !== 'undefined') {
    const stored = localStorage.getItem('reviews');
    return stored ? JSON.parse(stored) : [];
  }
  return [];
}