export async function GET(request: Request, { id }: { id: string }) {
  try {
    const product = await getProductById(id);
    
    if (!product) {
      return new Response(JSON.stringify({ error: 'Product not found' }), {
        status: 404,
        headers: { 'Content-Type': 'application/json' }
      });
    }

    return new Response(JSON.stringify({
      success: true,
      product
    }), {
      status: 200,
      headers: { 'Content-Type': 'application/json' }
    });

  } catch (error) {
    console.error('Get product error:', error);
    return new Response(JSON.stringify({ error: 'Internal server error' }), {
      status: 500,
      headers: { 'Content-Type': 'application/json' }
    });
  }
}

export async function PUT(request: Request, { id }: { id: string }) {
  try {
    const authHeader = request.headers.get('Authorization');
    const user = await verifyToken(authHeader);
    
    if (!user || user.role !== 'admin') {
      return new Response(JSON.stringify({ error: 'Unauthorized' }), {
        status: 401,
        headers: { 'Content-Type': 'application/json' }
      });
    }

    const updateData = await request.json();
    const updatedProduct = await updateProduct(id, updateData);
    
    if (!updatedProduct) {
      return new Response(JSON.stringify({ error: 'Product not found' }), {
        status: 404,
        headers: { 'Content-Type': 'application/json' }
      });
    }

    return new Response(JSON.stringify({
      success: true,
      product: updatedProduct
    }), {
      status: 200,
      headers: { 'Content-Type': 'application/json' }
    });

  } catch (error) {
    console.error('Update product error:', error);
    return new Response(JSON.stringify({ error: 'Internal server error' }), {
      status: 500,
      headers: { 'Content-Type': 'application/json' }
    });
  }
}

export async function DELETE(request: Request, { id }: { id: string }) {
  try {
    const authHeader = request.headers.get('Authorization');
    const user = await verifyToken(authHeader);
    
    if (!user || user.role !== 'admin') {
      return new Response(JSON.stringify({ error: 'Unauthorized' }), {
        status: 401,
        headers: { 'Content-Type': 'application/json' }
      });
    }

    const deleted = await deleteProduct(id);
    
    if (!deleted) {
      return new Response(JSON.stringify({ error: 'Product not found' }), {
        status: 404,
        headers: { 'Content-Type': 'application/json' }
      });
    }

    return new Response(JSON.stringify({
      success: true,
      message: 'Product deleted successfully'
    }), {
      status: 200,
      headers: { 'Content-Type': 'application/json' }
    });

  } catch (error) {
    console.error('Delete product error:', error);
    return new Response(JSON.stringify({ error: 'Internal server error' }), {
      status: 500,
      headers: { 'Content-Type': 'application/json' }
    });
  }
}

async function getProductById(id: string) {
  const products = getStoredProducts();
  return products.find(product => product.id === id);
}

async function updateProduct(id: string, updateData: any) {
  const products = getStoredProducts();
  const productIndex = products.findIndex(product => product.id === id);
  
  if (productIndex === -1) {
    return null;
  }
  
  products[productIndex] = {
    ...products[productIndex],
    ...updateData,
    updatedAt: new Date().toISOString()
  };
  
  storeProducts(products);
  return products[productIndex];
}

async function deleteProduct(id: string) {
  const products = getStoredProducts();
  const productIndex = products.findIndex(product => product.id === id);
  
  if (productIndex === -1) {
    return false;
  }
  
  products.splice(productIndex, 1);
  storeProducts(products);
  return true;
}

async function verifyToken(authHeader: string | null) {
  if (!authHeader || !authHeader.startsWith('Bearer ')) {
    return null;
  }
  
  try {
    const token = authHeader.substring(7);
    const decoded = JSON.parse(atob(token));
    
    if (decoded.exp < Date.now()) {
      return null;
    }
    
    return decoded;
  } catch {
    return null;
  }
}

function getStoredProducts() {
  if (typeof window !== 'undefined') {
    const stored = localStorage.getItem('products');
    return stored ? JSON.parse(stored) : [];
  }
  return [];
}

function storeProducts(products: any[]) {
  if (typeof window !== 'undefined') {
    localStorage.setItem('products', JSON.stringify(products));
  }
}