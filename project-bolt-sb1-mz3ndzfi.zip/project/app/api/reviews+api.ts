export async function GET(request: Request) {
  try {
    const url = new URL(request.url);
    const productId = url.searchParams.get('productId');
    
    if (!productId) {
      return new Response(JSON.stringify({ error: 'Product ID is required' }), {
        status: 400,
        headers: { 'Content-Type': 'application/json' }
      });
    }

    const reviews = await getProductReviews(productId);

    return new Response(JSON.stringify({
      success: true,
      reviews
    }), {
      status: 200,
      headers: { 'Content-Type': 'application/json' }
    });

  } catch (error) {
    console.error('Get reviews error:', error);
    return new Response(JSON.stringify({ error: 'Internal server error' }), {
      status: 500,
      headers: { 'Content-Type': 'application/json' }
    });
  }
}

export async function POST(request: Request) {
  try {
    const authHeader = request.headers.get('Authorization');
    const user = await verifyToken(authHeader);
    
    if (!user) {
      return new Response(JSON.stringify({ error: 'Unauthorized' }), {
        status: 401,
        headers: { 'Content-Type': 'application/json' }
      });
    }

    const reviewData = await request.json();
    
    // Validate required fields
    const requiredFields = ['productId', 'rating', 'comment'];
    for (const field of requiredFields) {
      if (!reviewData[field]) {
        return new Response(JSON.stringify({ error: `${field} is required` }), {
          status: 400,
          headers: { 'Content-Type': 'application/json' }
        });
      }
    }

    // Validate rating
    if (reviewData.rating < 1 || reviewData.rating > 5) {
      return new Response(JSON.stringify({ error: 'Rating must be between 1 and 5' }), {
        status: 400,
        headers: { 'Content-Type': 'application/json' }
      });
    }

    // Check if user already reviewed this product
    const existingReview = await getUserProductReview(user.userId, reviewData.productId);
    if (existingReview) {
      return new Response(JSON.stringify({ error: 'You have already reviewed this product' }), {
        status: 409,
        headers: { 'Content-Type': 'application/json' }
      });
    }

    const review = await createReview({
      ...reviewData,
      userId: user.userId,
      userName: user.name || 'Anonymous'
    });

    // Update product rating
    await updateProductRating(reviewData.productId);

    return new Response(JSON.stringify({
      success: true,
      review
    }), {
      status: 201,
      headers: { 'Content-Type': 'application/json' }
    });

  } catch (error) {
    console.error('Create review error:', error);
    return new Response(JSON.stringify({ error: 'Internal server error' }), {
      status: 500,
      headers: { 'Content-Type': 'application/json' }
    });
  }
}

async function getProductReviews(productId: string) {
  const reviews = getStoredReviews();
  return reviews.filter(review => review.productId === productId)
    .sort((a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime());
}

async function getUserProductReview(userId: string, productId: string) {
  const reviews = getStoredReviews();
  return reviews.find(review => review.userId === userId && review.productId === productId);
}

async function createReview(reviewData: any) {
  const reviews = getStoredReviews();
  const newReview = {
    id: Date.now().toString(),
    ...reviewData,
    createdAt: new Date().toISOString(),
    updatedAt: new Date().toISOString()
  };
  reviews.push(newReview);
  storeReviews(reviews);
  return newReview;
}

async function updateProductRating(productId: string) {
  const reviews = getStoredReviews();
  const productReviews = reviews.filter(review => review.productId === productId);
  
  if (productReviews.length === 0) return;
  
  const averageRating = productReviews.reduce((sum, review) => sum + review.rating, 0) / productReviews.length;
  
  const products = getStoredProducts();
  const productIndex = products.findIndex(product => product.id === productId);
  
  if (productIndex !== -1) {
    products[productIndex].rating = Math.round(averageRating * 10) / 10;
    products[productIndex].reviews = productReviews.length;
    storeProducts(products);
  }
}

async function verifyToken(authHeader: string | null) {
  if (!authHeader || !authHeader.startsWith('Bearer ')) {
    return null;
  }
  
  try {
    const token = authHeader.substring(7);
    const decoded = JSON.parse(atob(token));
    
    if (decoded.exp < Date.now()) {
      return null;
    }
    
    return decoded;
  } catch {
    return null;
  }
}

function getStoredReviews() {
  if (typeof window !== 'undefined') {
    const stored = localStorage.getItem('reviews');
    return stored ? JSON.parse(stored) : [];
  }
  return [];
}

function storeReviews(reviews: any[]) {
  if (typeof window !== 'undefined') {
    localStorage.setItem('reviews', JSON.stringify(reviews));
  }
}

function getStoredProducts() {
  if (typeof window !== 'undefined') {
    const stored = localStorage.getItem('products');
    return stored ? JSON.parse(stored) : [];
  }
  return [];
}

function storeProducts(products: any[]) {
  if (typeof window !== 'undefined') {
    localStorage.setItem('products', JSON.stringify(products));
  }
}