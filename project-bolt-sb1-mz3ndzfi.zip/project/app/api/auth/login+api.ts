export async function POST(request: Request) {
  try {
    const { email, password } = await request.json();

    // Validate input
    if (!email || !password) {
      return new Response(JSON.stringify({ error: 'Email and password are required' }), {
        status: 400,
        headers: { 'Content-Type': 'application/json' }
      });
    }

    // Find user by email
    const user = await getUserByEmail(email);
    if (!user) {
      return new Response(JSON.stringify({ error: 'Invalid credentials' }), {
        status: 401,
        headers: { 'Content-Type': 'application/json' }
      });
    }

    // Verify password
    const isValidPassword = await verifyPassword(password, user.password);
    if (!isValidPassword) {
      return new Response(JSON.stringify({ error: 'Invalid credentials' }), {
        status: 401,
        headers: { 'Content-Type': 'application/json' }
      });
    }

    // Generate JWT token
    const token = generateJWT({ userId: user.id, email: user.email, role: user.role });

    // Update last login
    await updateUserLastLogin(user.id);

    return new Response(JSON.stringify({
      success: true,
      user: {
        id: user.id,
        name: user.name,
        email: user.email,
        role: user.role,
        avatar: user.avatar
      },
      token
    }), {
      status: 200,
      headers: { 'Content-Type': 'application/json' }
    });

  } catch (error) {
    console.error('Login error:', error);
    return new Response(JSON.stringify({ error: 'Internal server error' }), {
      status: 500,
      headers: { 'Content-Type': 'application/json' }
    });
  }
}

async function getUserByEmail(email: string) {
  const users = getStoredUsers();
  return users.find(user => user.email === email);
}

async function verifyPassword(password: string, hashedPassword: string): Promise<boolean> {
  // In production, use bcrypt: return bcrypt.compare(password, hashedPassword);
  return btoa(password + 'salt') === hashedPassword;
}

async function updateUserLastLogin(userId: string) {
  const users = getStoredUsers();
  const userIndex = users.findIndex(user => user.id === userId);
  if (userIndex !== -1) {
    users[userIndex].lastLogin = new Date().toISOString();
    storeUsers(users);
  }
}

function generateJWT(payload: any): string {
  return btoa(JSON.stringify({ ...payload, exp: Date.now() + 86400000 }));
}

function getStoredUsers() {
  if (typeof window !== 'undefined') {
    const stored = localStorage.getItem('users');
    return stored ? JSON.parse(stored) : [];
  }
  return [];
}

function storeUsers(users: any[]) {
  if (typeof window !== 'undefined') {
    localStorage.setItem('users', JSON.stringify(users));
  }
}