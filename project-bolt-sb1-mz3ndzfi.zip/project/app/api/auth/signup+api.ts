export async function POST(request: Request) {
  try {
    const { name, email, password } = await request.json();

    // Validate input
    if (!name || !email || !password) {
      return new Response(JSON.stringify({ error: 'All fields are required' }), {
        status: 400,
        headers: { 'Content-Type': 'application/json' }
      });
    }

    // Email validation
    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    if (!emailRegex.test(email)) {
      return new Response(JSON.stringify({ error: 'Invalid email format' }), {
        status: 400,
        headers: { 'Content-Type': 'application/json' }
      });
    }

    // Password validation
    if (password.length < 6) {
      return new Response(JSON.stringify({ error: 'Password must be at least 6 characters' }), {
        status: 400,
        headers: { 'Content-Type': 'application/json' }
      });
    }

    // Check if user already exists
    const existingUser = await getUserByEmail(email);
    if (existingUser) {
      return new Response(JSON.stringify({ error: 'User already exists' }), {
        status: 409,
        headers: { 'Content-Type': 'application/json' }
      });
    }

    // Hash password
    const hashedPassword = await hashPassword(password);

    // Create user
    const user = await createUser({
      name,
      email,
      password: hashedPassword,
      role: 'customer'
    });

    // Generate JWT token
    const token = generateJWT({ userId: user.id, email: user.email, role: user.role });

    return new Response(JSON.stringify({
      success: true,
      user: {
        id: user.id,
        name: user.name,
        email: user.email,
        role: user.role
      },
      token
    }), {
      status: 201,
      headers: { 'Content-Type': 'application/json' }
    });

  } catch (error) {
    console.error('Signup error:', error);
    return new Response(JSON.stringify({ error: 'Internal server error' }), {
      status: 500,
      headers: { 'Content-Type': 'application/json' }
    });
  }
}

// Database functions (mock implementation - replace with real database)
async function getUserByEmail(email: string) {
  // In production, this would query your database
  const users = getStoredUsers();
  return users.find(user => user.email === email);
}

async function createUser(userData: any) {
  const users = getStoredUsers();
  const newUser = {
    id: Date.now().toString(),
    ...userData,
    createdAt: new Date().toISOString()
  };
  users.push(newUser);
  storeUsers(users);
  return newUser;
}

// Password hashing (simplified - use bcrypt in production)
async function hashPassword(password: string): Promise<string> {
  // In production, use bcrypt: const bcrypt = require('bcrypt'); return bcrypt.hash(password, 10);
  return btoa(password + 'salt'); // Simple base64 encoding for demo
}

// JWT token generation (simplified - use proper JWT library in production)
function generateJWT(payload: any): string {
  // In production, use jsonwebtoken: const jwt = require('jsonwebtoken'); return jwt.sign(payload, process.env.JWT_SECRET);
  return btoa(JSON.stringify({ ...payload, exp: Date.now() + 86400000 })); // 24 hours
}

// Simple storage functions (replace with real database)
function getStoredUsers() {
  if (typeof window !== 'undefined') {
    const stored = localStorage.getItem('users');
    return stored ? JSON.parse(stored) : [];
  }
  return [];
}

function storeUsers(users: any[]) {
  if (typeof window !== 'undefined') {
    localStorage.setItem('users', JSON.stringify(users));
  }
}