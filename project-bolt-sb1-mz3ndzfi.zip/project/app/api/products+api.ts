export async function GET(request: Request) {
  try {
    const url = new URL(request.url);
    const category = url.searchParams.get('category');
    const search = url.searchParams.get('search');
    const limit = parseInt(url.searchParams.get('limit') || '20');
    const offset = parseInt(url.searchParams.get('offset') || '0');

    let products = getStoredProducts();

    // Filter by category
    if (category && category !== 'all') {
      products = products.filter(product => 
        product.category.toLowerCase() === category.toLowerCase()
      );
    }

    // Filter by search query
    if (search) {
      const searchLower = search.toLowerCase();
      products = products.filter(product =>
        product.name.toLowerCase().includes(searchLower) ||
        product.description.toLowerCase().includes(searchLower) ||
        product.tags.some(tag => tag.toLowerCase().includes(searchLower))
      );
    }

    // Pagination
    const total = products.length;
    const paginatedProducts = products.slice(offset, offset + limit);

    return new Response(JSON.stringify({
      success: true,
      products: paginatedProducts,
      pagination: {
        total,
        limit,
        offset,
        hasMore: offset + limit < total
      }
    }), {
      status: 200,
      headers: { 'Content-Type': 'application/json' }
    });

  } catch (error) {
    console.error('Get products error:', error);
    return new Response(JSON.stringify({ error: 'Internal server error' }), {
      status: 500,
      headers: { 'Content-Type': 'application/json' }
    });
  }
}

export async function POST(request: Request) {
  try {
    const authHeader = request.headers.get('Authorization');
    const user = await verifyToken(authHeader);
    
    if (!user || user.role !== 'admin') {
      return new Response(JSON.stringify({ error: 'Unauthorized' }), {
        status: 401,
        headers: { 'Content-Type': 'application/json' }
      });
    }

    const productData = await request.json();
    
    // Validate required fields
    const requiredFields = ['name', 'description', 'price', 'category', 'stock', 'image'];
    for (const field of requiredFields) {
      if (!productData[field]) {
        return new Response(JSON.stringify({ error: `${field} is required` }), {
          status: 400,
          headers: { 'Content-Type': 'application/json' }
        });
      }
    }

    const product = await createProduct({
      ...productData,
      seller: user.name || 'Admin',
      rating: 0,
      reviews: 0,
      tags: productData.tags || []
    });

    return new Response(JSON.stringify({
      success: true,
      product
    }), {
      status: 201,
      headers: { 'Content-Type': 'application/json' }
    });

  } catch (error) {
    console.error('Create product error:', error);
    return new Response(JSON.stringify({ error: 'Internal server error' }), {
      status: 500,
      headers: { 'Content-Type': 'application/json' }
    });
  }
}

async function createProduct(productData: any) {
  const products = getStoredProducts();
  const newProduct = {
    id: Date.now().toString(),
    ...productData,
    createdAt: new Date().toISOString(),
    updatedAt: new Date().toISOString()
  };
  products.push(newProduct);
  storeProducts(products);
  return newProduct;
}

async function verifyToken(authHeader: string | null) {
  if (!authHeader || !authHeader.startsWith('Bearer ')) {
    return null;
  }
  
  try {
    const token = authHeader.substring(7);
    const decoded = JSON.parse(atob(token));
    
    if (decoded.exp < Date.now()) {
      return null;
    }
    
    return decoded;
  } catch {
    return null;
  }
}

function getStoredProducts() {
  if (typeof window !== 'undefined') {
    const stored = localStorage.getItem('products');
    return stored ? JSON.parse(stored) : getDefaultProducts();
  }
  return getDefaultProducts();
}

function storeProducts(products: any[]) {
  if (typeof window !== 'undefined') {
    localStorage.setItem('products', JSON.stringify(products));
  }
}

function getDefaultProducts() {
  return [
    {
      id: '1',
      name: 'iPhone 14 Pro',
      description: 'Latest Apple iPhone with Pro camera system and A16 Bionic chip',
      price: 999,
      originalPrice: 1199,
      image: 'https://images.pexels.com/photos/788946/pexels-photo-788946.jpeg?auto=compress&cs=tinysrgb&w=400',
      category: 'Electronics',
      stock: 15,
      rating: 4.8,
      reviews: 245,
      seller: 'TechStore',
      tags: ['smartphone', 'apple', 'pro'],
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString()
    },
    {
      id: '2',
      name: 'MacBook Air M2',
      description: 'Supercharged by M2 chip. Ultra-thin and lightweight laptop',
      price: 1299,
      originalPrice: 1499,
      image: 'https://images.pexels.com/photos/205421/pexels-photo-205421.jpeg?auto=compress&cs=tinysrgb&w=400',
      category: 'Electronics',
      stock: 8,
      rating: 4.9,
      reviews: 189,
      seller: 'Apple Store',
      tags: ['laptop', 'apple', 'macbook'],
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString()
    }
  ];
}