declare global {
  namespace NodeJS {
    interface ProcessEnv {
      EXPO_PUBLIC_API_URL: string;
      EXPO_PUBLIC_API_KEY: string;
      EXPO_PUBLIC_JWT_SECRET: string;
      EXPO_PUBLIC_STRIPE_PUBLISHABLE_KEY: string;
      EXPO_PUBLIC_PAYSTACK_PUBLIC_KEY: string;
      EXPO_PUBLIC_FLUTTERWAVE_PUBLIC_KEY: string;
    }
  }
}

export {};