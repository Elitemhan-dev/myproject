import React from 'react';
import { View, Text, Image, TouchableOpacity, StyleSheet, Platform } from 'react-native';
import { Star, ShoppingCart, Heart } from 'lucide-react-native';
import { Product } from '@/types';
import { useCart } from '@/context/CartContext';
import { useWishlist } from '@/context/WishlistContext';
import { useTheme } from '@/context/ThemeContext';

interface ProductCardProps {
  product: Product;
  onPress: () => void;
}

export default function ProductCard({ product, onPress }: ProductCardProps) {
  const { addToCart } = useCart();
  const { addToWishlist, removeFromWishlist, isInWishlist } = useWishlist();
  const { colors } = useTheme();
  const inWishlist = isInWishlist(product.id);

  const handleAddToCart = (e: any) => {
    e.stopPropagation();
    addToCart(product);
  };

  const handleToggleWishlist = (e: any) => {
    e.stopPropagation();
    if (inWishlist) {
      removeFromWishlist(product.id);
    } else {
      addToWishlist(product);
    }
  };

  const styles = createStyles(colors);

  return (
    <TouchableOpacity 
      style={styles.container} 
      onPress={onPress}
      activeOpacity={0.7}
    >
      <View style={styles.imageContainer}>
        <Image source={{ uri: product.image }} style={styles.image} />
        {product.originalPrice && (
          <View style={styles.discountBadge}>
            <Text style={styles.discountText}>
              {Math.round(((product.originalPrice - product.price) / product.originalPrice) * 100)}% OFF
            </Text>
          </View>
        )}
        <TouchableOpacity style={styles.favoriteButton} onPress={handleToggleWishlist}>
          <Heart 
            size={16} 
            color={inWishlist ? '#EF4444' : colors.textSecondary} 
            fill={inWishlist ? '#EF4444' : 'transparent'}
          />
        </TouchableOpacity>
      </View>
      
      <View style={styles.content}>
        <Text style={[styles.category, { color: colors.textSecondary }]}>{product.category}</Text>
        <Text style={[styles.name, { color: colors.text }]} numberOfLines={2}>{product.name}</Text>
        
        <View style={styles.rating}>
          <Star size={14} color="#FFC107" fill="#FFC107" />
          <Text style={[styles.ratingText, { color: colors.text }]}>{product.rating}</Text>
          <Text style={[styles.reviewText, { color: colors.textSecondary }]}>({product.reviews})</Text>
        </View>
        
        <View style={styles.priceContainer}>
          <Text style={[styles.price, { color: colors.primary }]}>${product.price}</Text>
          {product.originalPrice && (
            <Text style={[styles.originalPrice, { color: colors.textSecondary }]}>${product.originalPrice}</Text>
          )}
        </View>
        
        <View style={styles.footer}>
          <View style={styles.sellerContainer}>
            <Text style={[styles.seller, { color: colors.textSecondary }]} numberOfLines={1}>by {product.seller}</Text>
            <Text style={[styles.stock, { color: product.stock > 0 ? colors.success : colors.error }]}>
              {product.stock > 0 ? `${product.stock} left` : 'Out of stock'}
            </Text>
          </View>
          <TouchableOpacity 
            style={[
              styles.cartButton,
              { backgroundColor: product.stock === 0 ? colors.textSecondary : colors.primary }
            ]} 
            onPress={handleAddToCart}
            disabled={product.stock === 0}
          >
            <ShoppingCart size={16} color="#FFFFFF" />
          </TouchableOpacity>
        </View>
      </View>
    </TouchableOpacity>
  );
}

const createStyles = (colors: any) => StyleSheet.create({
  container: {
    backgroundColor: colors.card,
    borderRadius: 12,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.1,
    shadowRadius: 4,
    elevation: 3,
    marginBottom: 16,
    overflow: 'hidden',
    borderWidth: 1,
    borderColor: colors.border,
    ...Platform.select({
      web: {
        cursor: 'pointer',
        transition: 'transform 0.2s ease-in-out',
      },
    }),
  },
  imageContainer: {
    position: 'relative',
    height: 180,
  },
  image: {
    width: '100%',
    height: '100%',
    resizeMode: 'cover',
  },
  discountBadge: {
    position: 'absolute',
    top: 8,
    left: 8,
    backgroundColor: '#EF4444',
    paddingHorizontal: 8,
    paddingVertical: 4,
    borderRadius: 6,
  },
  discountText: {
    color: '#FFFFFF',
    fontSize: 10,
    fontWeight: '600',
  },
  favoriteButton: {
    position: 'absolute',
    top: 8,
    right: 8,
    width: 32,
    height: 32,
    borderRadius: 16,
    backgroundColor: 'rgba(255, 255, 255, 0.9)',
    justifyContent: 'center',
    alignItems: 'center',
  },
  content: {
    padding: 12,
  },
  category: {
    fontSize: 12,
    marginBottom: 4,
    textTransform: 'uppercase',
    fontWeight: '500',
  },
  name: {
    fontSize: 16,
    fontWeight: '600',
    marginBottom: 8,
    lineHeight: 20,
    minHeight: 40,
  },
  rating: {
    flexDirection: 'row',
    alignItems: 'center',
    marginBottom: 8,
  },
  ratingText: {
    fontSize: 14,
    marginLeft: 4,
    fontWeight: '500',
  },
  reviewText: {
    fontSize: 12,
    marginLeft: 4,
  },
  priceContainer: {
    flexDirection: 'row',
    alignItems: 'center',
    marginBottom: 12,
  },
  price: {
    fontSize: 18,
    fontWeight: '700',
  },
  originalPrice: {
    fontSize: 14,
    textDecorationLine: 'line-through',
    marginLeft: 8,
  },
  footer: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'flex-end',
  },
  sellerContainer: {
    flex: 1,
    marginRight: 8,
  },
  seller: {
    fontSize: 12,
    marginBottom: 2,
  },
  stock: {
    fontSize: 11,
    fontWeight: '500',
  },
  cartButton: {
    width: 36,
    height: 36,
    borderRadius: 18,
    justifyContent: 'center',
    alignItems: 'center',
  },
});