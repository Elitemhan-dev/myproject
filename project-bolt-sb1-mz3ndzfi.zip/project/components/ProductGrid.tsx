import React from 'react';
import { FlatList, View, StyleSheet } from 'react-native';
import ProductCard from './ProductCard';
import { Product } from '@/types';

interface ProductGridProps {
  products: Product[];
  onProductPress: (productId: string) => void;
  numColumns?: number;
  showsVerticalScrollIndicator?: boolean;
}

export default function ProductGrid({ 
  products, 
  onProductPress, 
  numColumns = 2,
  showsVerticalScrollIndicator = false 
}: ProductGridProps) {
  const renderProduct = ({ item, index }: { item: Product; index: number }) => (
    <View style={[
      styles.productContainer,
      { 
        marginLeft: index % numColumns === 0 ? 0 : 8,
        marginRight: index % numColumns === numColumns - 1 ? 0 : 8,
      }
    ]}>
      <ProductCard
        product={item}
        onPress={() => onProductPress(item.id)}
      />
    </View>
  );

  return (
    <FlatList
      data={products}
      renderItem={renderProduct}
      keyExtractor={(item) => item.id}
      numColumns={numColumns}
      contentContainerStyle={styles.container}
      showsVerticalScrollIndicator={showsVerticalScrollIndicator}
      columnWrapperStyle={numColumns > 1 ? styles.row : undefined}
    />
  );
}

const styles = StyleSheet.create({
  container: {
    padding: 16,
  },
  row: {
    justifyContent: 'space-between',
  },
  productContainer: {
    flex: 1,
    marginBottom: 16,
  },
});