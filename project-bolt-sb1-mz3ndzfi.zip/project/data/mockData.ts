import { Product, Category } from '@/types';

export const categories: Category[] = [
  { id: '1', name: 'Electronics', icon: 'smartphone', color: '#3B82F6' },
  { id: '2', name: 'Fashion', icon: 'shirt', color: '#EF4444' },
  { id: '3', name: 'Home & Garden', icon: 'home', color: '#10B981' },
  { id: '4', name: 'Sports', icon: 'dumbbell', color: '#F59E0B' },
  { id: '5', name: 'Books', icon: 'book', color: '#8B5CF6' },
  { id: '6', name: 'Beauty', icon: 'heart', color: '#EC4899' },
];

export const products: Product[] = [
  {
    id: '1',
    name: 'iPhone 14 Pro',
    description: 'Latest Apple iPhone with Pro camera system and A16 Bionic chip',
    price: 999,
    originalPrice: 1199,
    image: 'https://images.pexels.com/photos/788946/pexels-photo-788946.jpeg?auto=compress&cs=tinysrgb&w=400',
    category: 'Electronics',
    stock: 15,
    rating: 4.8,
    reviews: 245,
    seller: 'TechStore',
    tags: ['smartphone', 'apple', 'pro']
  },
  {
    id: '2',
    name: 'MacBook Air M2',
    description: 'Supercharged by M2 chip. Ultra-thin and lightweight laptop',
    price: 1299,
    originalPrice: 1499,
    image: 'https://images.pexels.com/photos/205421/pexels-photo-205421.jpeg?auto=compress&cs=tinysrgb&w=400',
    category: 'Electronics',
    stock: 8,
    rating: 4.9,
    reviews: 189,
    seller: 'Apple Store',
    tags: ['laptop', 'apple', 'macbook']
  },
  {
    id: '3',
    name: 'Nike Air Max 270',
    description: 'Comfortable running shoes with Air Max technology',
    price: 150,
    originalPrice: 200,
    image: 'https://images.pexels.com/photos/2529148/pexels-photo-2529148.jpeg?auto=compress&cs=tinysrgb&w=400',
    category: 'Sports',
    stock: 25,
    rating: 4.6,
    reviews: 156,
    seller: 'Nike Official',
    tags: ['shoes', 'nike', 'running']
  },
  {
    id: '4',
    name: 'Wireless Headphones',
    description: 'Premium noise-cancelling wireless headphones',
    price: 199,
    originalPrice: 299,
    image: 'https://images.pexels.com/photos/3394650/pexels-photo-3394650.jpeg?auto=compress&cs=tinysrgb&w=400',
    category: 'Electronics',
    stock: 12,
    rating: 4.7,
    reviews: 98,
    seller: 'AudioTech',
    tags: ['headphones', 'wireless', 'audio']
  },
  {
    id: '5',
    name: 'Summer Dress',
    description: 'Elegant floral summer dress perfect for any occasion',
    price: 89,
    originalPrice: 120,
    image: 'https://images.pexels.com/photos/985635/pexels-photo-985635.jpeg?auto=compress&cs=tinysrgb&w=400',
    category: 'Fashion',
    stock: 18,
    rating: 4.5,
    reviews: 67,
    seller: 'Fashion Hub',
    tags: ['dress', 'summer', 'fashion']
  },
  {
    id: '6',
    name: 'Coffee Maker',
    description: 'Automatic drip coffee maker with programmable timer',
    price: 79,
    originalPrice: 99,
    image: 'https://images.pexels.com/photos/324028/pexels-photo-324028.jpeg?auto=compress&cs=tinysrgb&w=400',
    category: 'Home & Garden',
    stock: 22,
    rating: 4.4,
    reviews: 134,
    seller: 'KitchenPro',
    tags: ['coffee', 'kitchen', 'appliance']
  },
  {
    id: '7',
    name: 'Yoga Mat',
    description: 'Non-slip yoga mat with alignment lines',
    price: 35,
    originalPrice: 50,
    image: 'https://images.pexels.com/photos/4056723/pexels-photo-4056723.jpeg?auto=compress&cs=tinysrgb&w=400',
    category: 'Sports',
    stock: 30,
    rating: 4.3,
    reviews: 89,
    seller: 'FitLife',
    tags: ['yoga', 'fitness', 'exercise']
  },
  {
    id: '8',
    name: 'Skincare Set',
    description: 'Complete skincare routine with cleanser, toner, and moisturizer',
    price: 45,
    originalPrice: 65,
    image: 'https://images.pexels.com/photos/3018845/pexels-photo-3018845.jpeg?auto=compress&cs=tinysrgb&w=400',
    category: 'Beauty',
    stock: 20,
    rating: 4.6,
    reviews: 78,
    seller: 'Beauty Co',
    tags: ['skincare', 'beauty', 'cosmetics']
  }
];

export const featuredProducts = products.slice(0, 4);
export const bestSellers = products.slice(2, 6);